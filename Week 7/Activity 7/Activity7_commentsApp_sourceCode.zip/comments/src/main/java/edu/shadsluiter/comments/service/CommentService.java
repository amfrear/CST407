package edu.shadsluiter.comments.service;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import edu.shadsluiter.comments.models.Comment;

@Service
public class CommentService {

    private final List<Comment> comments = new CopyOnWriteArrayList<>(); // CopyOnWriteArrayList is thread-safe
    private int id = 0;
    private int maxId = 0;


    public CommentService () {

        if (comments.isEmpty()) {
            addInitialComments();
        }
    }
       

    private void addInitialComments() {
        comments.add(new Comment(1, "Alice", "This is a comment from Alice"));
        comments.add(new Comment(2, "Bob", "This is a comment from Bob"));
        comments.add(new Comment(3, "Charlie", "This is a comment from Charlie"));
    }


    public List<Comment> getComments() {
        return comments;
    }

    public void addComment(Comment comment) {
        int newId = 0;
       // find new max
        for (Comment c : comments) {
            if (c.getId() > maxId) {
                maxId = c.getId();
            }
        }
        newId = maxId + 1;
        comment.setId(newId);
        comments.add(comment);
    }

    public void deleteComment(int id) {
        comments.removeIf(c -> c.getId() == id);
    }

    public void updateComment(int id, Comment comment) {
        for (Comment c : comments) {
            if (c.getId() == id) {
                c.setAuthor(comment.getAuthor());
                c.setText(comment.getText());
                break;
            }
        }
    }

    public Comment getComment(int id) {
        return comments.stream()
            .filter(c -> c.getId() == id)
            .findFirst()
            .orElse(null);
    }

    public List<Comment> searchForComment(String searchPhrase) {
        String lowerCasePhrase = searchPhrase.toLowerCase();
        return comments.stream()
            .filter(c -> c.getAuthor().toLowerCase().contains(lowerCasePhrase) ||
                         c.getText().toLowerCase().contains(lowerCasePhrase))
            .collect(Collectors.toList());
    }
}
