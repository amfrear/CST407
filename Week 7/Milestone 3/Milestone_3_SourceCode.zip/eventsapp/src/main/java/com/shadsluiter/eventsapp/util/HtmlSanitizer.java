package com.shadsluiter.eventsapp.util;

import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;
import org.springframework.stereotype.Component;

/**
 * HtmlSanitizer
 *
 * Purpose:
 * - This Spring component provides a central way to sanitize user-supplied text
 *   before storing it in the database or rendering it in the UI.
 * - It uses the jsoup library to clean input and strip out any HTML or JavaScript
 *   that could be used in a Cross-Site Scripting (XSS) attack.
 */
@Component   // Marks this class as a Spring-managed bean so it can be injected into services
public class HtmlSanitizer {

    /**
     * Safelist configuration:
     * - Safelist.none() means no HTML tags are allowed at all.
     * - If input contains <script>, <img>, or any other tags, they will be removed entirely.
     * - This ensures the safest approach by only keeping plain text.
     *
     * Other options:
     * - Safelist.basic() allows simple formatting tags (b, i, ul, etc.)
     * - Safelist.relaxed() allows a wider range of safe HTML tags.
     *
     * For this project, we are using none() to strictly block all HTML.
     */
    private static final Safelist SAFE = Safelist.none();

    /**
     * sanitize()
     *
     * @param input - raw user input string (e.g., event description)
     * @return a cleaned version of the input with all HTML removed
     *
     * Logic:
     * - If the input is null, just return null (avoid NullPointerException).
     * - Otherwise, call Jsoup.clean(), which strips out any tags or unsafe content
     *   using the configured Safelist.
     *
     * Example:
     *   Input:  "<script>alert('xss')</script> Hello!"
     *   Output: " Hello!"
     */
    public String sanitize(String input) {
        if (input == null) return null;
        return Jsoup.clean(input, SAFE);
    }
}
