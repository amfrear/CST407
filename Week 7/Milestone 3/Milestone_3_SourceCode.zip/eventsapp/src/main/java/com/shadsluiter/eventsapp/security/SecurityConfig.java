package com.shadsluiter.eventsapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

/**
 * SecurityConfig
 *
 * Big picture:
 * - We define TWO separate security filter chains with different behavior:
 *   1) API chain (JWT, stateless, CORS, CSRF disabled) for /api/** endpoints
 *   2) MVC chain (form login, stateful session, CSRF ON) for server-rendered pages
 *
 * Why split chains?
 * - APIs are typically consumed by JS clients and should be stateless (no HTTP session).
 * - MVC pages use Spring Security's form login and rely on the HTTP session.
 * - Different needs = different configs. The @Order annotation decides which chain is evaluated first.
 */
@Configuration
public class SecurityConfig {

  /** Our custom JWT authentication filter (parses Authorization: Bearer <token>) */
  private final JwtAuthFilter jwtAuthFilter;

  public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
    this.jwtAuthFilter = jwtAuthFilter;
  }

  // =========================
  // 1) API CHAIN: /api/** 
  //    - Stateless (no HTTP session)
  //    - JWT-based auth
  //    - CORS enabled for local dev client
  //    - CSRF disabled (not needed for stateless APIs)
  // =========================
  @Bean
  @Order(1) // This chain is evaluated FIRST for matching requests
  public SecurityFilterChain apiChain(HttpSecurity http) throws Exception {
    http
      // Apply this chain ONLY to /api/** endpoints
      .securityMatcher("/api/**")

      // APIs are stateless => we disable CSRF token requirement
      .csrf(AbstractHttpConfigurer::disable)

      // CORS: allow our static test client (e.g., VSCode Live Server on :5500) to call the API
      .cors(c -> c.configurationSource(req -> {
        CorsConfiguration cfg = new CorsConfiguration();
        // Allowed origins (adjust as needed)
        cfg.setAllowedOrigins(List.of("http://localhost:5500", "http://127.0.0.1:5500"));
        // Allowed HTTP methods for cross-origin requests
        cfg.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
        // Headers the client may send
        cfg.setAllowedHeaders(List.of("Authorization","Content-Type"));
        // With JWT, we usually keep credentials false; token rides in Authorization header
        cfg.setAllowCredentials(false);
        return cfg;
      }))

      // No HTTP session: each request carries its own auth (the JWT)
      .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

      // Authorization rules for API endpoints
      .authorizeHttpRequests(auth -> auth
        // Open endpoints: user registration and login (they issue tokens)
        .requestMatchers(HttpMethod.POST, "/api/users/register", "/api/users/login").permitAll()
        // Public reads of events via API (adjust as your app requires)
        .requestMatchers(HttpMethod.GET, "/api/events/**").permitAll()
        // Everything else under /api/** requires a valid JWT
        .anyRequest().authenticated()
      )

      // Insert our JWT filter BEFORE UsernamePasswordAuthenticationFilter so it can set Authentication
      .addFilterBefore(
        jwtAuthFilter,
        org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class
      );

    return http.build();
  }

  // =========================
  // 2) MVC CHAIN: /** (everything else)
  //    - Stateful session
  //    - Form login (custom login page)
  //    - CSRF ON (default) to protect form POSTs
  // =========================
  @Bean
  @Order(2) // Evaluated after the API chain; matches anything not already matched
  public SecurityFilterChain mvcChain(HttpSecurity http) throws Exception {
    http
      // Apply this chain to everything (the API chain already claimed /api/**)
      .securityMatcher("/**")

      // CSRF: ON by default for MVC; this line is equivalent to "keep defaults"
      // If you wanted to exclude specific endpoints, you'd configure csrf().ignoringRequestMatchers(...)
      .csrf(Customizer.withDefaults())

      // Authorization rules for pages/assets
      .authorizeHttpRequests(auth -> auth
        // Public pages/resources (login, register, home, static assets)
        .requestMatchers("/", "/users/loginForm", "/users/register", "/css/**").permitAll()
        // All other pages require the user to be logged in
        .anyRequest().authenticated()
      )

      // Form login configuration
      .formLogin(fl -> fl
        .loginPage("/users/loginForm")        // our Thymeleaf login page
        .loginProcessingUrl("/login")         // Spring Security handles POST /login
        .defaultSuccessUrl("/events", true)   // after login, go to events
        .failureUrl("/users/loginForm?error") // add ?error on failure so the view can show a message
        .permitAll()
      )

      // Logout configuration
      .logout(l -> l
        .logoutUrl("/logout")
        .logoutSuccessUrl("/users/loginForm?logout")
      )

      // MVC uses HTTP session when needed (not stateless like API)
      .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED));

    return http.build();
  }

  /**
   * Password encoder used for hashing user passwords (BCrypt is the standard choice).
   * - New users are saved with BCrypt-hashed passwords.
   * - During login, raw password is matched against the stored hash.
   */
  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  /**
   * AuthenticationManager is obtained from Spring (it knows our UserDetailsService, etc.).
   * - Controllers/services can @Autowired this if they need programmatic authentication.
   */
  @Bean
  public AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
    return cfg.getAuthenticationManager();
  }
}
