package com.shadsluiter.eventsapp.service;

import com.shadsluiter.eventsapp.data.EventRepositoryInterface;
import com.shadsluiter.eventsapp.models.EventEntity;
import com.shadsluiter.eventsapp.models.EventModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

// ✅ Sanitizer used to neutralize potential XSS in user-supplied fields
import com.shadsluiter.eventsapp.util.HtmlSanitizer;

/**
 * EventService
 *
 * What this class does (big picture):
 * - Acts as the "business logic" layer for Events. Controllers call this, and it talks to the repository/DB.
 * - Converts between persistence objects (EventEntity) and web/API objects (EventModel).
 * - Implements security-related hygiene (sanitize inputs) before data is persisted.
 *
 * Why this matters in Milestone 3:
 * - Sanitizing on write (here in save/update) + escaping on render (Thymeleaf th:text)
 *   gives us defense-in-depth against XSS. Even if a future template accidentally renders raw HTML,
 *   the database will already contain a safe version of the string.
 */
@Service
public class EventService {

    /** Repository abstraction for persistence operations (find/save/delete). */
    private final EventRepositoryInterface eventRepository;

    /** Spring-managed sanitizer bean (constructor-injected). */
    private final HtmlSanitizer htmlSanitizer;

    /**
     * Constructor injection:
     * - Preferred over field injection for immutability and easier testing.
     * - Spring provides the repository and sanitizer beans automatically.
     */
    @Autowired
    public EventService(EventRepositoryInterface eventRepository,
                        HtmlSanitizer htmlSanitizer) {
        this.eventRepository = eventRepository;
        this.htmlSanitizer = htmlSanitizer;
    }

    // ---------- Queries ----------

    /**
     * Fetch all events from the DB and map to API models.
     * @return List<EventModel> safe for controllers/views.
     */
    public List<EventModel> findAll() {
        List<EventEntity> eventEntities = eventRepository.findAll();
        return convertToModels(eventEntities);
    }

    /**
     * Find events by organizer id (String input converted to Long for the repo).
     * @param organizerid String id coming from web/API layer.
     */
    public List<EventModel> findByOrganizerid(String organizerid) {
        List<EventEntity> eventEntities = eventRepository.findByOrganizerid(Long.valueOf(organizerid));
        return convertToModels(eventEntities);
    }

    /**
     * Find a single event by id.
     * - Returns null instead of throwing so controllers can return 404 cleanly.
     */
    public EventModel findById(String id) {
        try {
            EventEntity eventEntity = eventRepository.findById(Long.valueOf(id));
            return convertToModel(eventEntity);
        } catch (EmptyResultDataAccessException ex) {
            return null; // lets API/controller return 404
        }
    }

    /**
     * Delegate to repository "search by description".
     * Note: repository decides how matching is performed (LIKE, full-text, etc.).
     */
    public List<EventModel> findByDescription(String searchString) {
        List<EventEntity> eventEntities = eventRepository.findByDescription(searchString);
        return convertToModels(eventEntities);
    }

    /**
     * Simple in-memory keyword search across name/description/location.
     * - Used by /api/events?q=... endpoint.
     * - For small datasets this is fine; for large data, offload to DB query.
     */
    public List<EventModel> searchByKeyword(String q) {
        if (q == null || q.isBlank()) return findAll();
        String needle = q.toLowerCase();
        List<EventEntity> all = eventRepository.findAll();
        List<EventEntity> filtered = new ArrayList<>();
        for (EventEntity e : all) {
            if (e == null) continue;
            boolean matches =
                (e.getName() != null && e.getName().toLowerCase().contains(needle)) ||
                (e.getDescription() != null && e.getDescription().toLowerCase().contains(needle)) ||
                (e.getLocation() != null && e.getLocation().toLowerCase().contains(needle));
            if (matches) filtered.add(e);
        }
        return convertToModels(filtered);
    }

    // ---------- Mutations ----------

    /**
     * Create or update an event.
     *
     * Security note:
     * - We sanitize user-supplied strings BEFORE saving (sanitize-on-write).
     * - Combined with Thymeleaf's th:text (escape-on-render), this blocks stored XSS.
     *
     * @param event EventModel coming from controllers (includes untrusted input)
     * @return the saved EventModel (freshly mapped back from the saved entity)
     */
    public EventModel save(EventModel event) {
        // ✅ Sanitize user input fields likely to show up in views
        //    (We must at least sanitize "description" per milestone; you can safely add name/location too)
        event.setDescription(htmlSanitizer.sanitize(event.getDescription()));
        // Optional hardening:
        // event.setName(htmlSanitizer.sanitize(event.getName()));
        // event.setLocation(htmlSanitizer.sanitize(event.getLocation()));

        // Convert to entity for persistence, save, then map back to model for return
        EventEntity eventEntity = convertToEntity(event);
        EventEntity savedEvent = eventRepository.save(eventEntity);
        return convertToModel(savedEvent);
    }

    /**
     * Update an event by id via save().
     * - Sets the id on the model so save() treats it as an update.
     * - Reuses the same sanitize + convert + persist flow in save().
     */
    public EventModel updateEvent(String id, EventModel event) {
        event.setId(id);
        return save(event);
    }

    /**
     * Delete by id (String -> Long conversion).
     * - Controllers handle existence/authorization checks before calling this.
     */
    public void delete(String id) {
        eventRepository.deleteById(Long.valueOf(id));
    }

    // ---------- Mapping helpers ----------

    /**
     * Map a list of entities to models, skipping nulls defensively.
     */
    private List<EventModel> convertToModels(List<EventEntity> eventEntities) {
        List<EventModel> eventModels = new ArrayList<>();
        if (eventEntities == null) return eventModels;
        for (EventEntity eventEntity : eventEntities) {
            if (eventEntity != null) {
                eventModels.add(convertToModel(eventEntity));
            }
        }
        return eventModels;
    }

    /**
     * Map one EventEntity into an EventModel.
     * Note on dates:
     * - Any sql.Date -> util.Date quirks are handled upstream; we pass through here.
     */
    private EventModel convertToModel(EventEntity eventEntity) {
        if (eventEntity == null) return null;
        return new EventModel(
            eventEntity.getId() != null ? eventEntity.getId().toString() : null,
            eventEntity.getName(),
            eventEntity.getDate(),          // already compatible with forms/JSON in this project
            eventEntity.getLocation(),
            eventEntity.getOrganizerid(),
            eventEntity.getDescription()
        );
    }

    /**
     * Map one EventModel into an EventEntity for persistence.
     * - Converts String id -> Long.
     * - Converts util.Date -> sql.Date for JDBC.
     */
    private EventEntity convertToEntity(EventModel eventModel) {
        EventEntity eventEntity = new EventEntity();

        if (eventModel.getId() != null && !eventModel.getId().isBlank()) {
            eventEntity.setId(Long.parseLong(eventModel.getId()));
        }

        eventEntity.setName(eventModel.getName());

        // Convert java.util.Date -> java.sql.Date for JDBC column compatibility
        if (eventModel.getDate() != null) {
            eventEntity.setDate(new java.sql.Date(eventModel.getDate().getTime()));
        } else {
            eventEntity.setDate(null);
        }

        eventEntity.setLocation(eventModel.getLocation());
        eventEntity.setOrganizerid(eventModel.getOrganizerid());
        eventEntity.setDescription(eventModel.getDescription());

        return eventEntity;
    }
}
