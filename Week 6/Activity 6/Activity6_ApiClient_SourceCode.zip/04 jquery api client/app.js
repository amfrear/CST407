$(document).ready(function() {
    const BASE_URL = 'http://localhost:8080/api'; // central base URL
    let token = null;

    // Handle registration
    $('#registerForm').submit(function(event) {
        event.preventDefault();
        const registerData = {
            loginName: $('#registerLoginName').val(),
            password: $('#registerPassword').val(), 
        };

        $.ajax({
            url: `${BASE_URL}/users/register`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(registerData),
            success: function(response) {
                alert('Registration successful');
            },
            error: function(xhr, status, error) {
                alert('Registration failed: ' + xhr.responseText);
            }
        });
    });

    // Handle login
    $('#loginForm').submit(function(event) {
        event.preventDefault();
        const loginData = {
            loginName: $('#loginLoginName').val(),
            password: $('#loginPassword').val()
        };

        console.log(loginData);

        $.ajax({
            url: `${BASE_URL}/users/login`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(loginData),
            success: function(response) {
                token = response.token;
                alert('Login successful. Token: ' + token);
            },
            error: function(xhr, status, error) {
                alert('Login failed: ' + xhr.responseText);
            }
        });
    });

    // Get all orders
    $('#getOrdersButton').click(function() { 
        $.ajax({
            url: `${BASE_URL}/orders`,
            type: 'GET',
            headers: {
                'Authorization': 'Bearer ' + (token ?? '')
            },
            success: function(response) { 
                $('#ordersResult').text(JSON.stringify(response, null, 2));
            },
            error: function(xhr, status, error) {
                alert('Failed to get orders: ' + xhr.responseText);
            }
        });
    });

    // Create an order
    $('#createOrderForm').submit(function(event) {
        event.preventDefault();
        
        const orderData = {
            notes: $('#notes').val(),
            date: $('#date').val() 
        };

        $.ajax({
            url: `${BASE_URL}/orders`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(orderData), 
            headers: {
                'Authorization': 'Bearer ' + (token ?? '')
            },
            success: function(response) {
                alert('Order created successfully'); 
            },
            error: function(xhr, status, error) {
                alert('Failed to create order: ' + xhr.responseText);
            }
        });
    });
});
