package com.shadsluiter.ordersapp.security;

import com.shadsluiter.ordersapp.models.UserModel;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class CustomUserDetails implements UserDetails {

    private final UserModel user;

    public CustomUserDetails(UserModel user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Single role column (e.g., "USER" or "ADMIN")
        String role = user.getRole() == null || user.getRole().isBlank() ? "USER" : user.getRole();
        String springRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;
        return List.of(new SimpleGrantedAuthority(springRole));
    }

    @Override public String getPassword() { return user.getPassword(); }
    @Override public String getUsername() { return user.getLoginName(); } // login by loginName
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return true; }

    public String getId() { return user.getId(); }
    public UserModel getUser() { return user; }
}
