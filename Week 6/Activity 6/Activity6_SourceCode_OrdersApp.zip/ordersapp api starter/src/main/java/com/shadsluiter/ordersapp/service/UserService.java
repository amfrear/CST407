package com.shadsluiter.ordersapp.service;

import com.shadsluiter.ordersapp.data.UserRepository;
import com.shadsluiter.ordersapp.models.UserEntity;
import com.shadsluiter.ordersapp.models.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserModel save(UserModel userModel) {
        UserEntity entity = toEntity(userModel);
        UserEntity saved  = userRepository.save(entity);
        return toModel(saved);
    }

    public UserModel findByLoginName(String loginName) {
        UserEntity entity = userRepository.findByLoginName(loginName);
        return toModel(entity);
    }

    // ---- Mapping helpers ----

    private UserModel toModel(UserEntity e) {
        if (e == null) return null;

        UserModel m = new UserModel();
        m.setId(e.getId() == null ? null : Long.toString(e.getId()));
        m.setLoginName(e.getLoginName());
        m.setPassword(e.getPassword());
        m.setRole(e.getRole());                    // <-- copy role from entity
        return m;
    }

    private UserEntity toEntity(UserModel m) {
        if (m == null) return null;

        UserEntity e = new UserEntity();
        if (m.getId() != null) {
            try { e.setId(Long.parseLong(m.getId())); } catch (NumberFormatException ignore) {}
        }
        e.setLoginName(m.getLoginName());
        e.setPassword(m.getPassword());
        e.setRole((m.getRole() == null || m.getRole().isBlank()) ? "USER" : m.getRole()); // <-- copy/default role
        return e;
    }
}
