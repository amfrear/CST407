package com.shadsluiter.ordersapp.controllers;

import com.shadsluiter.ordersapp.models.OrderModel;
import com.shadsluiter.ordersapp.models.UserModel;
import com.shadsluiter.ordersapp.service.OrderService;
import com.shadsluiter.ordersapp.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RestController
@RequestMapping("/api/orders")
public class OrdersController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    /** Helper: get the current authenticated user model by principal name (loginName). */
    private UserModel currentUser(Authentication auth) {
        if (auth == null || auth.getName() == null) return null;
        return userService.findByLoginName(auth.getName());
    }

    /** GET all orders for the currently authenticated user */
    @GetMapping
    public ResponseEntity<List<OrderModel>> getMyOrders(Authentication auth) {
        UserModel me = currentUser(auth);
        if (me == null) return ResponseEntity.status(401).build();
        List<OrderModel> orders = orderService.findByCustomerid(me.getId());
        return ResponseEntity.ok(orders);
    }

    /** GET orders for a specific customer id (guide requires this endpoint) */
    @GetMapping("/{customerid}")
    public ResponseEntity<List<OrderModel>> getOrdersByCustomerId(@PathVariable("customerid") String customerid) {
        List<OrderModel> orders = orderService.findByCustomerid(customerid);
        return ResponseEntity.ok(orders);
    }

    /** POST create a new order for the current user */
    @PostMapping
    public ResponseEntity<OrderModel> createOrder(@RequestBody OrderModel incoming, Authentication auth) {
        UserModel me = currentUser(auth);
        if (me == null) return ResponseEntity.status(401).build();

        // Tie the order to the logged-in user
        incoming.setCustomerid(me.getId());

        // Default date if not provided
        if (incoming.getDate() == null) {
            incoming.setDate(new Date());
        }

        OrderModel saved = orderService.save(incoming);
        return ResponseEntity.ok(saved);
    }

    /** PUT update (service updates by id) */
    @PutMapping("/{id}")
    public ResponseEntity<OrderModel> updateOrder(@PathVariable("id") String id,
                                                  @RequestBody OrderModel patch,
                                                  Authentication auth) {
        UserModel me = currentUser(auth);
        if (me == null) return ResponseEntity.status(401).build();

        // NOTE: To make it truly "null-safe", you'd need a findById + merge.
        // Your service doesn't expose findById; for the assignment, calling updateOrder is sufficient.
        OrderModel updated = orderService.updateOrder(id, patch);
        return ResponseEntity.ok(updated);
    }

    /** DELETE order by id */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable("id") String id, Authentication auth) {
        UserModel me = currentUser(auth);
        if (me == null) return ResponseEntity.status(401).build();

        orderService.delete(id);
        return ResponseEntity.ok().build();
    }
}
