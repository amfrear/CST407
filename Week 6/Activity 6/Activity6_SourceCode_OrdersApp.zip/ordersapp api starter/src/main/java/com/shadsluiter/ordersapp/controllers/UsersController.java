package com.shadsluiter.ordersapp.controllers;

import com.shadsluiter.ordersapp.models.UserModel;
import com.shadsluiter.ordersapp.security.JwtTokenProvider;
import com.shadsluiter.ordersapp.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RestController
@RequestMapping("/api/users")
public class UsersController {

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    // ---- DTOs for requests ----
    public static class RegisterRequest {
        public String loginName;
        public String password;
        public String role; // <-- NEW: allow passing role (optional)
    }

    public static class LoginRequest {
        public String loginName;
        public String password;
    }

    // POST /api/users/register -> hash password and save
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (req == null || req.loginName == null || req.password == null
                || req.loginName.isBlank() || req.password.isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("loginName and password are required");
        }

        UserModel existing = userService.findByLoginName(req.loginName);
        if (existing != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("loginName already exists");
        }

        UserModel user = new UserModel();
        user.setLoginName(req.loginName);
        user.setPassword(passwordEncoder.encode(req.password));       // store hashed password
        user.setRole(req.role != null ? req.role : "USER");           // <-- use provided role, default USER

        UserModel saved = userService.save(user);
        saved.setPassword("***"); // mask
        return ResponseEntity.ok(saved);
    }

    // POST /api/users/login -> validate password and return JWT (includes role)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        if (req == null || req.loginName == null || req.password == null
                || req.loginName.isBlank() || req.password.isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("loginName and password are required");
        }

        UserModel user = userService.findByLoginName(req.loginName);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        boolean passwordOk = passwordEncoder.matches(req.password, user.getPassword());
        if (!passwordOk) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        String token = jwtTokenProvider.generateToken(user.getLoginName(), user.getRole());

        Map<String, String> body = new HashMap<>();
        body.put("token", token);
        return ResponseEntity.ok(body);
    }
}
