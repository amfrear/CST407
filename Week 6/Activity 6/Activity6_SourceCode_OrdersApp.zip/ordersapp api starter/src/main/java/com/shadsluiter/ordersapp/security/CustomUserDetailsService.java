package com.shadsluiter.ordersapp.security;

import com.shadsluiter.ordersapp.models.UserModel;
import com.shadsluiter.ordersapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserService userService; // must expose findByLoginName(String)

    @Override
    public UserDetails loadUserByUsername(String loginName) throws UsernameNotFoundException {
        UserModel user = userService.findByLoginName(loginName);
        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + loginName);
        }
        return new CustomUserDetails(user);
    }
}
