package com.shadsluiter.eventsapp.data;

import java.util.List;

import com.shadsluiter.eventsapp.models.EventEntity;

/**
 * EventRepositoryInterface
 *
 * Defines the contract for Event repository operations.
 *
 * Purpose in the milestone:
 * - Provides a clear list of database operations supported for events.
 * - Implemented by EventRepository using JdbcTemplate.
 * - Demonstrates the separation of interface and implementation in the data layer.
 */
public interface EventRepositoryInterface {

    /**
     * Find all events created by a specific organizer.
     *
     * @param organizerid the id of the organizer
     * @return list of events for that organizer
     */
    List<EventEntity> findByOrganizerid(Long organizerid);

    /**
     * Find all events in the database.
     *
     * @return list of all events
     */
    List<EventEntity> findAll();

    /**
     * Delete an event by its id.
     *
     * @param id the id of the event
     */
    void deleteById(Long id);

    /**
     * Save a new event or update an existing one.
     *
     * @param event the event to save
     * @return the saved event (with id set if newly created)
     */
    EventEntity save(EventEntity event);

    /**
     * Find an event by its id.
     *
     * @param id the id of the event
     * @return the event if found
     */
    EventEntity findById(Long id);

    /**
     * Check if an event exists by id.
     *
     * @param id the id of the event
     * @return true if the event exists, false otherwise
     */
    boolean existsById(Long id);

    /**
     * Find events that contain a keyword in their description.
     *
     * @param description keyword to search for
     * @return list of matching events
     */
    List<EventEntity> findByDescription(String description);
}
