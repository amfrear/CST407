package com.shadsluiter.eventsapp.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.shadsluiter.eventsapp.data.UserRepository;
import com.shadsluiter.eventsapp.models.Converters;
import com.shadsluiter.eventsapp.models.UserEntity;
import com.shadsluiter.eventsapp.models.UserModel;

/**
 * UserService
 *
 * Purpose in the milestone:
 * - Encapsulates user-related business logic.
 * - Converts between UserEntity (DB) and UserModel (web/API).
 * - Ensures account flags and roles are set sensibly.
 * - Encodes passwords before persistence.
 */
@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ---------- Queries ----------

    /**
     * Return all users as UserModel list.
     */
    public List<UserModel> findAll() {
        List<UserEntity> entities = userRepository.findAll();
        List<UserModel> models = new ArrayList<>();
        for (UserEntity e : entities) {
            models.add(Converters.userEntityToUserModel(e));
        }
        return models;
    }

    /**
     * Find a user by id (String -> Long). Returns null if not found.
     */
    public UserModel findById(String id) {
        UserEntity entity = userRepository.findById(Long.valueOf(id));
        if (entity == null) return null;
        return Converters.userEntityToUserModel(entity);
    }

    /**
     * Delete a user by id (String -> Long).
     */
    public void delete(String id) {
        userRepository.deleteById(Long.valueOf(id));
    }

    // ---------- Mutations ----------

    /**
     * Create or update a user.
     *
     * Steps:
     * - Map model -> entity.
     * - Set default account flags if not already true.
     * - Ensure at least ROLE_USER is present.
     * - Encode the password if it looks raw (not already BCrypt).
     * - Save and return the saved model.
     */
    public UserModel save(UserModel userModel) {
        UserEntity entity = Converters.userModelToUserEntity(userModel);

        // Default account flags (assignment-friendly defaults)
        if (!entity.isEnabled())               entity.setEnabled(true);
        if (!entity.isAccountNonExpired())     entity.setAccountNonExpired(true);
        if (!entity.isCredentialsNonExpired()) entity.setCredentialsNonExpired(true);
        if (!entity.isAccountNonLocked())      entity.setAccountNonLocked(true);

        // Ensure at least ROLE_USER
        Set<String> roles = entity.getRoles();
        if (roles == null || roles.isEmpty()) {
            roles = new HashSet<>();
            roles.add("ROLE_USER");
            entity.setRoles(roles);
        }

        // Encode plain password if not already BCrypt
        String pw = entity.getPassword();
        if (pw != null && !pw.isBlank() && !looksEncoded(pw)) {
            entity.setPassword(passwordEncoder.encode(pw));
        }

        UserEntity saved = userRepository.save(entity);
        return Converters.userEntityToUserModel(saved);
    }

    // ---------- Convenience / Compatibility ----------

    /**
     * Find by username (used by API login and validation).
     */
    public UserModel findByUserName(String userName) {
        UserEntity e = userRepository.findByLoginName(userName);
        if (e == null) return null;
        return Converters.userEntityToUserModel(e);
    }

    /**
     * Back-compat alias for Milestone 1 code that called findByLoginName(...).
     */
    public UserModel findByLoginName(String loginName) {
        return findByUserName(loginName);
    }

    /**
     * Exposed for tests: compare raw vs encoded.
     */
    public boolean passwordMatches(String raw, String encoded) {
        return passwordEncoder.matches(raw, encoded);
    }

    // ---------- Helpers ----------

    /**
     * Heuristic to detect if a password already looks BCrypt-encoded.
     * BCrypt hashes usually start with $2a$, $2b$, or $2y$ and are ~60 chars.
     */
    private boolean looksEncoded(String pw) {
        return pw.startsWith("$2a$") || pw.startsWith("$2b$") || pw.startsWith("$2y$");
    }
}
