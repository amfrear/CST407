package com.shadsluiter.eventsapp.controllers;

import com.shadsluiter.eventsapp.models.UserModel;
import com.shadsluiter.eventsapp.security.JwtUtil;
import com.shadsluiter.eventsapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * UsersApiController
 *
 * REST controller for user registration and login.
 *
 * Purpose in the milestone:
 * - Demonstrates creating a user with validation for duplicates.
 * - Shows how to verify passwords using a PasswordEncoder.
 * - Issues JWT tokens on successful login with user id and roles in the claims.
 *
 * CORS:
 * - @CrossOrigin allows local front-ends on 127.0.0.1:5500 / localhost:5500.
 */
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RestController
@RequestMapping("/api/users")
public class UsersApiController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Autowired
    public UsersApiController(UserService userService,
                              PasswordEncoder passwordEncoder,
                              JwtUtil jwtUtil) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    /**
     * POST /api/users/register
     * Registers a new user.
     *
     * Steps:
     * - Check if username already exists → return 409 Conflict if it does.
     * - Save the new user (password should be encoded before saving).
     * - Return 201 Created with the saved user.
     */
    @PostMapping("/register")
    public ResponseEntity<UserModel> register(@RequestBody UserModel body) {
        UserModel existing = userService.findByUserName(body.getUserName());
        if (existing != null) {
            return ResponseEntity.status(409).build();
        }
        UserModel saved = userService.save(body);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    /**
     * POST /api/users/login
     * Authenticates a user and returns a JWT token.
     *
     * Steps:
     * - Validate input is not null.
     * - Look up the user by username.
     * - Use PasswordEncoder to compare plain password to stored hash.
     * - If valid, build claims (uid and roles) and generate a JWT.
     * - Return 200 OK with a JSON response: { "token": "..." }.
     * - Return 401 Unauthorized on any failure.
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody UserModel body) {
        if (body == null || body.getUserName() == null || body.getPassword() == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        UserModel existing = userService.findByUserName(body.getUserName());
        if (existing == null || existing.getPassword() == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        boolean ok = passwordEncoder.matches(body.getPassword(), existing.getPassword());
        if (!ok) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Map<String,Object> claims = new HashMap<>();
        claims.put("uid", existing.getId());
        claims.put("roles", existing.getRoles());

        String token = jwtUtil.generateToken(existing.getUserName(), claims);

        Map<String,String> resp = new HashMap<>();
        resp.put("token", token);
        return ResponseEntity.ok(resp);
    }
}
