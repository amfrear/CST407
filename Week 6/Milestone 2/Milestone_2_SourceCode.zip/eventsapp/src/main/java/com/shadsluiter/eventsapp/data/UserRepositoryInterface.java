package com.shadsluiter.eventsapp.data;

import java.util.List;

import com.shadsluiter.eventsapp.models.UserEntity;

/**
 * UserRepositoryInterface
 *
 * Defines the contract for user repository operations.
 * 
 * Purpose in the milestone:
 * - Separates the interface from the implementation (`UserRepository`).
 * - Lists all database operations supported for users.
 * - Allows for flexible swapping of implementations if needed.
 */
public interface UserRepositoryInterface {

    /**
     * Find a user by login name.
     *
     * @param loginName the username used for login
     * @return UserEntity if found, otherwise null
     */
    UserEntity findByLoginName(String loginName);

    /**
     * Find all users.
     *
     * @return list of all users
     */
    List<UserEntity> findAll();

    /**
     * Delete a user by id.
     *
     * @param id the user id
     */
    void deleteById(Long id);

    /**
     * Save a new user or update an existing one.
     *
     * @param user the user entity
     * @return the saved user entity
     */
    UserEntity save(UserEntity user);

    /**
     * Find a user by id.
     *
     * @param id the user id
     * @return the user if found, otherwise null
     */
    UserEntity findById(Long id);

    /**
     * Count total number of users.
     *
     * @return number of users in the table
     */
    long count();

    /**
     * Delete a specific user entity.
     *
     * @param user the user entity
     */
    void delete(UserEntity user);

    /**
     * Delete all users.
     */
    void deleteAll();

    /**
     * Delete multiple users.
     *
     * @param users iterable of users to delete
     */
    void deleteAll(Iterable<? extends UserEntity> users);

    /**
     * Save a list of users.
     *
     * @param users iterable of users
     * @return list of saved users
     */
    List<UserEntity> saveAll(Iterable<UserEntity> users);
}
