package com.shadsluiter.eventsapp.controllers;

import com.shadsluiter.eventsapp.models.EventModel;
import com.shadsluiter.eventsapp.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.util.List;

/**
 * EventsApiController
 *
 * Simple REST API for the Events feature used in the milestone assignment.
 * Shows how to expose JSON endpoints for list/detail + basic CRUD.
 *
 * Notes for the assignment:
 * - Public reads (GET): anyone can list/search and view by id.
 * - Mutations (POST/PUT/DELETE): require a JWT that was already validated
 *   by a filter. That filter stores the user id on the request as "uid".
 *   We read that "uid" and assign it to EventModel.organizerid so clients
 *   cannot spoof ownership.
 *
 * CORS:
 * - @CrossOrigin allows local static front-ends (127.0.0.1:5500 / localhost:5500)
 *   to call these endpoints during demos.
 */
@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://localhost:5500"})
@RestController
@RequestMapping("/api/events")
public class EventsApiController {

    private final EventService eventService;
    private final HttpServletRequest httpRequest;

    @Autowired
    public EventsApiController(EventService eventService, HttpServletRequest httpRequest) {
        this.eventService = eventService;
        this.httpRequest = httpRequest;
    }

    /**
     * GET /api/events?q=keyword
     * Public endpoint that returns all events or a filtered list by keyword.
     *
     * @param q optional search keyword (matches description/title based on service implementation).
     * @return 200 OK with JSON list of events.
     */
    @GetMapping
    public ResponseEntity<List<EventModel>> getAll(@RequestParam(value = "q", required = false) String q) {
        if (q == null || q.isBlank()) {
            return ResponseEntity.ok(eventService.findAll());
        }
        return ResponseEntity.ok(eventService.searchByKeyword(q));
    }

    /**
     * GET /api/events/{id}
     * Public endpoint to fetch a single event by id.
     *
     * @param id event id
     * @return 200 OK with the event, or 404 if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<EventModel> getById(@PathVariable String id) {
        EventModel found = eventService.findById(id);
        if (found == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(found);
    }

    /**
     * POST /api/events
     * Create an event. Requires a validated JWT (handled by a filter).
     * The filter places the authenticated user's id in request attribute "uid".
     * We assign that id to organizerid to establish ownership.
     *
     * Request body: EventModel (JSON). Client-supplied organizerid is ignored.
     * Response: 201 Created with Location header pointing to the new resource.
     */
    @PostMapping
    public ResponseEntity<EventModel> create(@RequestBody EventModel body) {
        // "uid" is set upstream by a JWT verification filter for this assignment.
        String uid = (String) httpRequest.getAttribute("uid");
        if (uid != null && !uid.isBlank()) {
            body.setOrganizerid(uid); // ignore any client-provided organizerid
        }

        EventModel saved = eventService.save(body);
        String id = saved.getId();
        return ResponseEntity
                .created(URI.create("/api/events/" + id))
                .body(saved);
    }

    /**
     * PUT /api/events/{id}
     * Update an existing event. Requires a validated JWT (same "uid" attribute).
     * We stamp organizerid from "uid" to keep ownership tied to the caller for the assignment.
     *
     * @param id   path id of the event to update
     * @param body JSON payload with updated fields
     * @return 200 with updated event, or 404 if the id does not exist.
     */
    @PutMapping("/{id}")
    public ResponseEntity<EventModel> update(@PathVariable String id, @RequestBody EventModel body) {
        EventModel existing = eventService.findById(id);
        if (existing == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        String uid = (String) httpRequest.getAttribute("uid");
        if (uid != null && !uid.isBlank()) {
            body.setOrganizerid(uid); // keep organizer tied to the authenticated user
        }

        EventModel saved = eventService.updateEvent(id, body);
        return ResponseEntity.ok(saved);
    }

    /**
     * DELETE /api/events/{id}
     * Delete an event by id. Requires a validated JWT.
     * (For the milestone, ownership/admin checks can be handled in the service
     *  or assumed to pass if the request is authenticated.)
     *
     * @param id event id
     * @return 204 No Content on success, or 404 if the id does not exist.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        EventModel existing = eventService.findById(id);
        if (existing == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        eventService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
