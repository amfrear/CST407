package com.shadsluiter.eventsapp.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.Map;

/**
 * JwtUtil
 *
 * Purpose in the milestone:
 * - Central helper for issuing and validating JWTs.
 * - Stores the signing key (derived from application properties) and token lifetime.
 *
 * Properties used (application.properties/.yml):
 * - app.jwt.secret            -> HMAC key material
 * - app.jwt.expirationMillis  -> token lifetime in milliseconds
 */
@Component
public class JwtUtil {

    private final Key key;                // HMAC signing key for HS256
    private final long expirationMillis;  // token lifespan

    /**
     * Build the signing key from the configured secret and capture token lifetime.
     */
    public JwtUtil(
            @Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expirationMillis}") long expirationMillis
    ) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expirationMillis = expirationMillis;
    }

    /**
     * Generate a signed JWT.
     *
     * @param username subject for the token (appears as "sub")
     * @param claims   extra key/value pairs to embed (e.g., uid, roles)
     * @return compact JWS string
     */
    public String generateToken(String username, Map<String, Object> claims) {
        long now = System.currentTimeMillis();
        Date issuedAt = new Date(now);
        Date expiry = new Date(now + expirationMillis);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(username)
                .setIssuedAt(issuedAt)
                .setExpiration(expiry)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * Extract the username (subject) from a token.
     */
    public String extractUsername(String token) {
        return getAllClaims(token).getSubject();
    }

    /**
     * Retrieve a custom claim by name (e.g., "uid").
     */
    public Object getClaim(String token, String keyName) {
        return getAllClaims(token).get(keyName);
    }

    /**
     * Quick validation used by the filter:
     * - Parses the token, checks signature and expiration
     * - Confirms the subject matches what we expect
     */
    public boolean isTokenValid(String token, String expectedUsername) {
        try {
            final String username = extractUsername(token);
            return username != null && username.equals(expectedUsername) && !isTokenExpired(token);
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * True if the token's exp is before "now".
     */
    private boolean isTokenExpired(String token) {
        Date expiration = getAllClaims(token).getExpiration();
        return expiration == null || expiration.before(new Date());
    }

    /**
     * Parse and return the Claims body (verifies signature with our key).
     */
    private Claims getAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}
