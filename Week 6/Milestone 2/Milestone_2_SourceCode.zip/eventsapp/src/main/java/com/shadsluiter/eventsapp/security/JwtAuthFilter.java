package com.shadsluiter.eventsapp.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * JwtAuthFilter
 *
 * Custom filter that runs once per request and checks for a JWT in the Authorization header.
 *
 * Purpose in the milestone:
 * - Demonstrates how to read a Bearer token from the request.
 * - Validates the token and extracts the username and custom claims.
 * - Loads user details and builds an Authentication object for Spring Security.
 * - Makes the "uid" claim available on the request so controllers can use it.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    /**
     * Runs on each request. Steps:
     * 1. Look for Authorization header starting with "Bearer ".
     * 2. Extract the JWT and parse the username from it.
     * 3. If the user is not already authenticated:
     *    - Load the user from the database.
     *    - Validate the token against the username.
     *    - Extract the "uid" claim and attach it to the request.
     *    - Create an Authentication object and store it in the SecurityContext.
     * 4. Continue with the filter chain.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws ServletException, IOException {

        final String authHeader = request.getHeader("Authorization");

        String username = null;
        String token = null;

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            try {
                username = jwtUtil.extractUsername(token);
            } catch (Exception ignored) { }
        }

        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            UserDetails details = userDetailsService.loadUserByUsername(username);

            if (jwtUtil.isTokenValid(token, details.getUsername())) {
                // Make uid claim available for controllers/services
                Object uid = jwtUtil.getClaim(token, "uid");
                if (uid != null) {
                    request.setAttribute("uid", String.valueOf(uid));
                }

                UsernamePasswordAuthenticationToken auth =
                        new UsernamePasswordAuthenticationToken(details, null, details.getAuthorities());
                auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        }

        chain.doFilter(request, response);
    }
}
