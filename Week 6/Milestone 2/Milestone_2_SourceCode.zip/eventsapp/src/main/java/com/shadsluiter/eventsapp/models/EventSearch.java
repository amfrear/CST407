package com.shadsluiter.eventsapp.models;

/**
 * EventSearch
 *
 * Simple model used for the event search form.
 *
 * Purpose in the milestone:
 * - Acts as a form-backing object in EventController for searching events.
 * - Holds the search string entered by the user.
 * - Validated/bound automatically by Spring when the form is submitted.
 */
public class EventSearch {

    private String searchString; // keyword entered by the user

    public EventSearch() {
        searchString = "";
    }

    public EventSearch(String searchString) {
        this.searchString = searchString;
    }

    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }
}
