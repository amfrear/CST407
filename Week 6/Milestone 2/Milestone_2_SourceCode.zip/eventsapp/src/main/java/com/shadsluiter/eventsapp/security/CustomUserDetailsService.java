package com.shadsluiter.eventsapp.security;

import com.shadsluiter.eventsapp.data.UserRepository;
import com.shadsluiter.eventsapp.models.UserEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.stream.Collectors;

/**
 * CustomUserDetailsService
 *
 * Purpose in the milestone:
 * - Bridges between your UserRepository (which knows how to load UserEntity from DB)
 *   and Spring Security's authentication system (which needs a UserDetails object).
 * - Called automatically by Spring Security whenever a login attempt is made.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

  private final UserRepository userRepository;

  public CustomUserDetailsService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  /**
   * Core entry point for Spring Security.
   *
   * Steps:
   * - Receives the submitted username from the login form.
   * - Loads the corresponding UserEntity from the repository.
   * - Converts roles (Set<String>) into GrantedAuthority objects.
   * - Builds and returns a Spring Security UserDetails object that the
   *   framework can use to check the password and store authentication info.
   *
   * @param username login name submitted by the user
   * @return UserDetails with username, encoded password, status flags, and roles
   * @throws UsernameNotFoundException if no user is found
   */
  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    UserEntity u = userRepository.findByLoginName(username);
    if (u == null) {
      throw new UsernameNotFoundException("User not found: " + username);
    }

    // Map role strings like "ROLE_USER" into GrantedAuthority objects
    Collection<? extends GrantedAuthority> authorities = u.getRoles().stream()
        .map(SimpleGrantedAuthority::new)
        .collect(Collectors.toList());

    // Build the Spring Security UserDetails object
    return new org.springframework.security.core.userdetails.User(
        u.getUserName(),              // principal username
        u.getPassword(),              // encoded password (e.g., BCrypt)
        u.isEnabled(),                // enabled flag
        u.isAccountNonExpired(),      // non-expired account
        u.isCredentialsNonExpired(),  // non-expired credentials
        u.isAccountNonLocked(),       // non-locked account
        authorities                   // granted authorities from roles
    );
  }
}
