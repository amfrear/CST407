package com.shadsluiter.eventsapp.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * SecurityConfig
 *
 * Purpose in the milestone:
 * - Splits security into two paths:
 *   1) API: stateless JWT for /api/**, no form login.
 *   2) MVC: form login for web pages (Thymeleaf).
 * - Shows how to mark certain endpoints as public vs. authenticated.
 * - Registers JwtAuthFilter before UsernamePasswordAuthenticationFilter for API requests.
 */
@Configuration
public class SecurityConfig {

    @Autowired
    private JwtAuthFilter jwtAuthFilter;

    /**
     * Password encoder used when creating users and verifying passwords.
     * (Matches what CustomUserDetailsService expects.)
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // -------------------- Filter Chain 1: API (JWT) --------------------

    /**
     * API chain: applies only to /api/**.
     * - CORS enabled.
     * - CSRF disabled.
     * - Stateless sessions (JWT in Authorization header).
     * - Public endpoints: register, login, and GET /api/events/** (public browse).
     * - All other /api/** requests require authentication.
     * - Returns 401/403 HTTP codes for auth errors.
     */
    @Bean
    @Order(1)
    public SecurityFilterChain apiChain(HttpSecurity http) throws Exception {
        http
            .securityMatcher("/api/**")
            .cors(Customizer.withDefaults())
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/users/register", "/api/users/login").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/events", "/api/events/", "/api/events/**").permitAll()
                .anyRequest().authenticated()
            )
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)) // 401
                .accessDeniedHandler((req, res, ex2) -> res.sendError(HttpStatus.FORBIDDEN.value())) // 403
            );

        // Insert JWT filter so it can set Authentication from the Bearer token.
        http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    // -------------------- Filter Chain 2: MVC (Form Login) --------------------

    /**
     * MVC chain: handles regular web pages.
     * - CORS enabled, CSRF disabled (simplified for the assignment).
     * - Public pages: home, register, events list + search, and static assets.
     * - Auth required: create/edit/delete event pages.
     * - Uses a custom login page, then redirects to /events after success.
     */
    @Bean
    @Order(2)
    public SecurityFilterChain mvcChain(HttpSecurity http) throws Exception {
        http
            .cors(Customizer.withDefaults())
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/",
                    "/users/",
                    "/users/register",
                    "/users/register/**",
                    "/events",
                    "/events/search",
                    "/events/search/**",
                    "/css/**", "/js/**", "/images/**"
                ).permitAll()
                .requestMatchers(
                    "/events/create",
                    "/events/edit/**",
                    "/events/delete/**"
                ).authenticated()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/users/loginForm")
                .defaultSuccessUrl("/events", true)
                .permitAll()
            )
            .logout(Customizer.withDefaults());

        return http.build();
    }

    /**
     * Exposes the AuthenticationManager that Spring Security configures.
     * Used by login flows that need to authenticate with the configured providers.
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
