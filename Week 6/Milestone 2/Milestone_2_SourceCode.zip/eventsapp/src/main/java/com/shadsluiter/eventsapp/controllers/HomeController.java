package com.shadsluiter.eventsapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * HomeController
 *
 * Simple controller that handles the root ("/") request
 * and returns the home page view.
 *
 * Purpose in the milestone:
 * - Demonstrates a basic controller mapping.
 * - Serves the landing page template (home.html).
 */
@Controller
@RequestMapping("/")
public class HomeController {

    /**
     * GET /
     * Returns the "home" view template.
     */
    @RequestMapping("/")
    public String home() {
        return "/home";
    }
}
