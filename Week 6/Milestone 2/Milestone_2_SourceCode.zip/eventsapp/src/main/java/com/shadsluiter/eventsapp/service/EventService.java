package com.shadsluiter.eventsapp.service;

import com.shadsluiter.eventsapp.data.EventRepositoryInterface;
import com.shadsluiter.eventsapp.models.EventEntity;
import com.shadsluiter.eventsapp.models.EventModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * EventService
 *
 * Purpose in the milestone:
 * - Encapsulates event-related business logic.
 * - Maps between persistence entities (EventEntity) and web/API models (EventModel).
 * - Delegates DB operations to EventRepositoryInterface.
 */
@Service
public class EventService {

    // Repository abstraction for persistence operations (find/save/delete).
    private final EventRepositoryInterface eventRepository;

    @Autowired
    public EventService(EventRepositoryInterface eventRepository) {
        this.eventRepository = eventRepository;
    }

    // ---------- Queries ----------

    /**
     * Return all events (maps Entity -> Model list).
     */
    public List<EventModel> findAll() {
        List<EventEntity> eventEntities = eventRepository.findAll();
        return convertToModels(eventEntities);
    }

    /**
     * Return all events for a given organizer id (String -> Long).
     */
    public List<EventModel> findByOrganizerid(String organizerid) {
        List<EventEntity> eventEntities = eventRepository.findByOrganizerid(Long.valueOf(organizerid));
        return convertToModels(eventEntities);
    }

    /**
     * Find a single event by id. Returns null if not found so controllers
     * can respond with 404 instead of throwing.
     */
    public EventModel findById(String id) {
        try {
            EventEntity eventEntity = eventRepository.findById(Long.valueOf(id));
            return convertToModel(eventEntity);
        } catch (EmptyResultDataAccessException ex) {
            return null; // lets API return 404
        }
    }

    /**
     * Search by description using the repository method.
     */
    public List<EventModel> findByDescription(String searchString) {
        List<EventEntity> eventEntities = eventRepository.findByDescription(searchString);
        return convertToModels(eventEntities);
    }

    /**
     * Simple in-memory keyword search over name/description/location.
     * Used by /api/events?q=... endpoint.
     */
    public List<EventModel> searchByKeyword(String q) {
        if (q == null || q.isBlank()) return findAll();
        String needle = q.toLowerCase();
        List<EventEntity> all = eventRepository.findAll();
        List<EventEntity> filtered = new ArrayList<>();
        for (EventEntity e : all) {
            if (e == null) continue;
            boolean matches =
                (e.getName() != null && e.getName().toLowerCase().contains(needle)) ||
                (e.getDescription() != null && e.getDescription().toLowerCase().contains(needle)) ||
                (e.getLocation() != null && e.getLocation().toLowerCase().contains(needle));
            if (matches) filtered.add(e);
        }
        return convertToModels(filtered);
    }

    // ---------- Mutations ----------

    /**
     * Create or update an event.
     * - Converts Model -> Entity, saves, then maps back to Model.
     */
    public EventModel save(EventModel event) {
        EventEntity eventEntity = convertToEntity(event);
        EventEntity savedEvent = eventRepository.save(eventEntity);
        return convertToModel(savedEvent);
    }

    /**
     * Update an event by id via save().
     * Sets the id on the model first so save() treats it as an update.
     */
    public EventModel updateEvent(String id, EventModel event) {
        event.setId(id);
        return save(event);
    }

    /**
     * Delete an event by id (String -> Long).
     */
    public void delete(String id) {
        eventRepository.deleteById(Long.valueOf(id));
    }

    // ---------- Mapping helpers ----------

    /**
     * Convert a list of entities to models, skipping nulls.
     */
    private List<EventModel> convertToModels(List<EventEntity> eventEntities) {
        List<EventModel> eventModels = new ArrayList<>();
        if (eventEntities == null) return eventModels;
        for (EventEntity eventEntity : eventEntities) {
            if (eventEntity != null) {
                eventModels.add(convertToModel(eventEntity));
            }
        }
        return eventModels;
    }

    /**
     * Map a single EventEntity into an EventModel.
     * Note: date conversion sql.Date -> util.Date is already handled upstream in Converters;
     * here we pass through the java.sql.Date, which the model constructor accepts.
     */
    private EventModel convertToModel(EventEntity eventEntity) {
        if (eventEntity == null) return null;
        return new EventModel(
            eventEntity.getId() != null ? eventEntity.getId().toString() : null,
            eventEntity.getName(),
            eventEntity.getDate(),          // handled for forms/JSON elsewhere
            eventEntity.getLocation(),
            eventEntity.getOrganizerid(),
            eventEntity.getDescription()
        );
    }

    /**
     * Map a single EventModel into an EventEntity.
     * Converts id and util.Date -> sql.Date as needed for JDBC.
     */
    private EventEntity convertToEntity(EventModel eventModel) {
        EventEntity eventEntity = new EventEntity();

        if (eventModel.getId() != null && !eventModel.getId().isBlank()) {
            eventEntity.setId(Long.parseLong(eventModel.getId()));
        }

        eventEntity.setName(eventModel.getName());

        // Convert java.util.Date -> java.sql.Date for JDBC
        if (eventModel.getDate() != null) {
            eventEntity.setDate(new java.sql.Date(eventModel.getDate().getTime()));
        } else {
            eventEntity.setDate(null);
        }

        eventEntity.setLocation(eventModel.getLocation());
        eventEntity.setOrganizerid(eventModel.getOrganizerid());
        eventEntity.setDescription(eventModel.getDescription());

        return eventEntity;
    }
}
