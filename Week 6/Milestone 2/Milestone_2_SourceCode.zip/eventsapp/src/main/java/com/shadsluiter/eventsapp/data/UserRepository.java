package com.shadsluiter.eventsapp.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.shadsluiter.eventsapp.models.UserEntity;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * UserRepository
 *
 * Data access layer for users using JdbcTemplate.
 * For the milestone, this shows:
 * - Basic CRUD queries over the users table
 * - Reading/writing user roles via a separate roles table
 * - Aggregating roles per user with a ResultSetExtractor
 */
@Repository
public class UserRepository implements UserRepositoryInterface {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Find a single user by login name and load any roles.
     * LEFT JOIN allows users with no roles to still be returned.
     */
    @Override
    public UserEntity findByLoginName(String loginName) {
        String sql = "SELECT u.*, r.role FROM users u LEFT JOIN roles r ON u.id = r.user_id WHERE u.login_name = '" + loginName + "'";
        try {
            List<UserEntity> users = jdbcTemplate.query(sql, new UserWithRolesExtractor());
            return users.isEmpty() ? null : users.get(0);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * Return all users with their roles.
     */
    @Override
    public List<UserEntity> findAll() {
        String sql = "SELECT u.*, r.role FROM users u LEFT JOIN roles r ON u.id = r.user_id";
        return jdbcTemplate.query(sql, new UserWithRolesExtractor());
    }

    /**
     * Delete a user by id.
     * (Assumes roles are handled separately.)
     */
    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM users WHERE id = " + id;
        jdbcTemplate.update(sql);
    }

    /**
     * Insert or update a user, then replace role records.
     * - New user: assign default roles (ROLE_USER + ROLE_ADMIN for this milestone),
     *             insert user, fetch new id.
     * - Existing user: update fields.
     * After saving the user, roles are cleared and re-inserted based on the
     * current set on the entity.
     */
    @Override
    public UserEntity save(UserEntity userEntity) {
        // new user
        if (userEntity.getId() == null) {

            // default roles for the milestone demo
            if (userEntity.getRoles() == null) {
                userEntity.setRoles(new HashSet<>(Arrays.asList("ROLE_USER", "ROLE_ADMIN")));
            } else {
                userEntity.getRoles().add("ROLE_USER");
            }

            String sql = "INSERT INTO users (login_name, password, enabled, account_non_expired, credentials_non_expired, account_non_locked) VALUES ('"
                    + userEntity.getUserName() + "', '"
                    + userEntity.getPassword() + "', "
                    + userEntity.isEnabled() + ", "
                    + userEntity.isAccountNonExpired() + ", "
                    + userEntity.isCredentialsNonExpired() + ", "
                    + userEntity.isAccountNonLocked() + ")";
            jdbcTemplate.update(sql);
            Long id = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
            userEntity.setId(id);
        } else {
            String sql = "UPDATE users SET login_name = '" + userEntity.getUserName()
                    + "', password = '" + userEntity.getPassword()
                    + "', enabled = " + userEntity.isEnabled()
                    + ", account_non_expired = " + userEntity.isAccountNonExpired()
                    + ", credentials_non_expired = " + userEntity.isCredentialsNonExpired()
                    + ", account_non_locked = " + userEntity.isAccountNonLocked()
                    + " WHERE id = " + userEntity.getId();
            jdbcTemplate.update(sql);
        }

        // Replace role rows for this user based on the entity's current roles
        deleteRoles(userEntity);
        saveRoles(userEntity);

        return userEntity;
    }

    /**
     * Insert each role for the given user id.
     */
    public void saveRoles(UserEntity userEntity) {
        if (userEntity.getRoles() != null) {
            for (String role : userEntity.getRoles()) {
                String sql = "INSERT INTO roles (user_id, role) VALUES (" + userEntity.getId() + ", '" + role + "')";
                jdbcTemplate.update(sql);
            }
        }
    }

    /**
     * Remove all role rows for a user id (used before re-inserting).
     */
    public void deleteRoles(UserEntity userEntity) {
        String sql = "DELETE FROM roles WHERE user_id = " + userEntity.getId();
        jdbcTemplate.update(sql);
    }

    /**
     * Find a user by id and load roles.
     */
    @Override
    public UserEntity findById(Long id) {
        String sql = "SELECT u.*, r.role FROM users u LEFT JOIN roles r ON u.id = r.user_id WHERE u.id = " + id;
        try {
            List<UserEntity> users = jdbcTemplate.query(sql, new UserWithRolesExtractor());
            return users.isEmpty() ? null : users.get(0);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * Count total users in the table.
     */
    @Override
    public long count() {
        String sql = "SELECT COUNT(*) FROM users";
        Long result = jdbcTemplate.queryForObject(sql, Long.class);
        return result != null ? result : 0;
    }

    /**
     * Convenience delete by entity.
     */
    @Override
    public void delete(UserEntity user) {
        deleteById(user.getId());
    }

    /**
     * Delete all users (no filter).
     */
    @Override
    public void deleteAll() {
        String sql = "DELETE FROM users";
        jdbcTemplate.update(sql);
    }

    /**
     * Delete a list of users.
     */
    @Override
    public void deleteAll(Iterable<? extends UserEntity> users) {
        for (UserEntity user : users) {
            delete(user);
        }
    }

    /**
     * Save a list of users (calls save for each).
     */
    @Override
    public List<UserEntity> saveAll(Iterable<UserEntity> users) {
        for (UserEntity user : users) {
            save(user);
        }
        return (List<UserEntity>) users;
    }

    /**
     * Aggregates rows from users JOIN roles so each UserEntity gets a Set<String> of roles.
     * If a user has multiple role rows, they are merged into one entity in the map.
     */
    private static class UserWithRolesExtractor implements ResultSetExtractor<List<UserEntity>> {
        @Override
        public List<UserEntity> extractData(ResultSet rs) throws SQLException, DataAccessException {
            Map<Long, UserEntity> userMap = new HashMap<>();
            while (rs.next()) {
                Long id = rs.getLong("id");
                UserEntity user = userMap.get(id);
                if (user == null) {
                    user = new UserEntity();
                    user.setId(id);
                    user.setUserName(rs.getString("login_name"));
                    user.setPassword(rs.getString("password"));
                    user.setEnabled(rs.getBoolean("enabled"));
                    user.setAccountNonExpired(rs.getBoolean("account_non_expired"));
                    user.setCredentialsNonExpired(rs.getBoolean("credentials_non_expired"));
                    user.setAccountNonLocked(rs.getBoolean("account_non_locked"));
                    user.setRoles(new HashSet<>());
                    userMap.put(id, user);
                }
                String role = rs.getString("role");
                if (role != null) {
                    user.getRoles().add(role);
                }
            }
            return new ArrayList<>(userMap.values());
        }
    }
}
