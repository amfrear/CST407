package com.shadsluiter.eventsapp.models;

import java.util.HashSet;
import java.util.Set;

/**
 * UserEntity
 *
 * Database-facing representation of a user.
 *
 * Purpose in the milestone:
 * - Represents a row in the "users" table.
 * - Used by the repository and service layers when working with users.
 * - Stores login credentials, account status flags, and assigned roles.
 *
 * Notes:
 * - Roles are stored in a Set<String> to avoid duplicates.
 * - Account flags (enabled, non-expired, non-locked) support Spring Security checks.
 */
public class UserEntity {

    private Long id;                  // Primary key in DB
    private String userName;          // Login name
    private String password;          // Hashed password
    private boolean enabled;          // Is the account active
    private boolean accountNonExpired;       // Account expiration flag
    private boolean credentialsNonExpired;   // Credential expiration flag
    private boolean accountNonLocked;        // Lockout flag
    private Set<String> roles = new HashSet<>(); // Assigned roles (ROLE_USER, ROLE_ADMIN, etc.)

    // ----- Constructors -----
    public UserEntity() {
    }

    public UserEntity(Long id, String userName, String password) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.roles = new HashSet<>();
    }

    // ----- Getters and setters -----
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String loginName) {
        this.userName = loginName;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }
    public void setAccountNonExpired(boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }
    public void setCredentialsNonExpired(boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }
    public void setAccountNonLocked(boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    public Set<String> getRoles() {
        return roles;
    }
    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }
}
