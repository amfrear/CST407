package com.shadsluiter.eventsapp.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shadsluiter.eventsapp.models.UserModel;
import com.shadsluiter.eventsapp.service.UserService;

/**
 * UsersController
 *
 * MVC controller that handles user-facing pages for login and registration.
 *
 * Purpose in the milestone:
 * - Shows how to render a login form (view only, authentication handled by Spring Security).
 * - Implements a basic registration page with validation and duplicate checking.
 * - Saves new users with default account settings and hands off to UserService for password encoding.
 */
@Controller
@RequestMapping("/users")
public class UsersController {

    private static final Logger log = LoggerFactory.getLogger(UsersController.class);

    private final UserService userService;

    public UsersController(UserService userService) {
        this.userService = userService;
    }

    /**
     * GET /users/
     * Simply returns the home page view.
     */
    @GetMapping("/")
    public String home() {
        return "home";
    }

    // ---------- LOGIN ----------

    /**
     * GET /users/loginForm
     * Renders the login page. 
     *
     * Note: The actual POST /login is handled automatically by Spring Security,
     * not by this controller.
     */
    @GetMapping("/loginForm")
    public String showLoginForm(Model model) {
        model.addAttribute("pageTitle", "Login");
        return "login";
    }

    // ---------- REGISTER ----------

    /**
     * GET /users/register
     * Displays the registration form.
     */
    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register";
    }

    /**
     * POST /users/register
     * Handles submission of the registration form.
     *
     * Steps:
     * - Validate that username and password are not blank.
     * - Check if the username already exists.
     * - Create a new UserModel with defaults (enabled, not expired/locked).
     * - Save the user through UserService (which encodes the password).
     * - Redirect to login page with a success message.
     */
    @PostMapping("/register")
    public String register(@RequestParam("userName") String userName,
                           @RequestParam("password") String password,
                           Model model,
                           RedirectAttributes ra) {

        if (userName == null || userName.isBlank() || password == null || password.isBlank()) {
            model.addAttribute("error", "Username and password are required.");
            return "register";
        }

        var existing = userService.findByLoginName(userName);
        if (existing != null) {
            model.addAttribute("error", "That username is already taken.");
            return "register";
        }

        var user = new UserModel();
        user.setUserName(userName);
        user.setPassword(password);
        user.setEnabled(true);
        user.setAccountNonExpired(true);
        user.setCredentialsNonExpired(true);
        user.setAccountNonLocked(true);

        userService.save(user);
        log.info("User registered: {}", userName);

        return "redirect:/users/loginForm?registered";
    }

    // Logout is handled by Spring Security at /logout.
    // Example link in template: <a th:href="@{/logout}">Logout</a>
}
