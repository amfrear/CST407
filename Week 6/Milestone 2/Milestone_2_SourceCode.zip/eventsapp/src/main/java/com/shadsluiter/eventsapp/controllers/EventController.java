package com.shadsluiter.eventsapp.controllers;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shadsluiter.eventsapp.models.EventModel;
import com.shadsluiter.eventsapp.models.EventSearch;
import com.shadsluiter.eventsapp.models.UserModel;
import com.shadsluiter.eventsapp.service.EventService;
import com.shadsluiter.eventsapp.service.UserService;

/**
 * EventController
 *
 * Handles all routes under /events. 
 * Provides pages for listing, creating, editing, deleting, 
 * and searching events. 
 * 
 * For the milestone assignment:
 * - Demonstrates CRUD operations with form binding and validation.
 * - Shows how to check the current user from the security context.
 * - Restricts edit/delete to the event owner or an admin.
 */
@Controller
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;
    private final UserService userService;

    @Autowired
    public EventController(EventService eventService, UserService userService) {
        this.eventService = eventService;
        this.userService = userService;
    }

    // ---------- helpers ----------

    /**
     * Gets the id of the currently logged in user.
     * Returns null if no user is logged in.
     */
    private String currentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            return null;
        }
        UserModel u = userService.findByLoginName(auth.getName());
        return (u != null) ? u.getId() : null;
    }

    /**
     * Checks if the current user has the ADMIN role.
     */
    private boolean isAdmin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            return false;
        }
        for (GrantedAuthority a : auth.getAuthorities()) {
            if ("ROLE_ADMIN".equals(a.getAuthority())) return true;
        }
        return false;
    }

    /**
     * Checks if the current user is the owner of the given event.
     */
    private boolean isOwner(String eventId) {
        EventModel ev = eventService.findById(eventId);
        String me = currentUserId();
        return ev != null && me != null && me.equals(ev.getOrganizerid());
    }

    // ---------- routes ----------

    /**
     * GET /events
     * Displays a list of all events.
     */
    @GetMapping
    public String getAllEvents(Model model) {
        List<EventModel> events = eventService.findAll();
        model.addAttribute("events", events);
        model.addAttribute("message", "Showing all events");
        model.addAttribute("pageTitle", "Events");
        model.addAttribute("currentUserId", currentUserId());
        return "events";
    }

    /**
     * GET /events/create
     * Shows the form for creating a new event.
     */
    @GetMapping("/create")
    public String showCreateEventForm(Model model) {
        model.addAttribute("event", new EventModel());
        model.addAttribute("pageTitle", "Create Event");
        model.addAttribute("users", userService.findAll());
        return "create-event";
    }

    /**
     * POST /events/create
     * Handles the form submission for creating an event.
     * Validates the form and assigns the organizer to the logged-in user.
     */
    @PostMapping("/create")
    public String createEvent(@ModelAttribute @Valid EventModel event,
                              BindingResult result,
                              Model model,
                              RedirectAttributes ra) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", "Create Event");
            model.addAttribute("users", userService.findAll());
            return "create-event";
        }

        String me = currentUserId();
        if (me != null) {
            event.setOrganizerid(me);
        }

        eventService.save(event);
        ra.addFlashAttribute("message", "Event created.");
        return "redirect:/events";
    }

    /**
     * GET /events/edit/{id}
     * Shows the form for editing an event.
     * Only the owner or an admin can access it.
     */
    @GetMapping("/edit/{id}")
    public String showEditEventForm(@PathVariable String id,
                                    Model model,
                                    RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only edit your own events (admins can edit all).");
            return "redirect:/events";
        }

        model.addAttribute("event", eventService.findById(id));
        model.addAttribute("users", userService.findAll());
        return "edit-event";
    }

    /**
     * POST /events/edit/{id}
     * Handles the form submission for updating an event.
     * Owner or admin only.
     */
    @PostMapping("/edit/{id}")
    public String updateEvent(@PathVariable String id,
                              @ModelAttribute EventModel event,
                              BindingResult result,
                              Model model,
                              RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only edit your own events (admins can edit all).");
            return "redirect:/events";
        }

        if (result.hasErrors()) {
            model.addAttribute("event", event);
            model.addAttribute("users", userService.findAll());
            return "edit-event";
        }

        String me = currentUserId();
        if (me != null) {
            event.setOrganizerid(me);
        }

        eventService.updateEvent(id, event);
        ra.addFlashAttribute("message", "Event updated.");
        return "redirect:/events";
    }

    /**
     * GET /events/delete/{id}
     * Deletes an event. 
     * Only the owner or an admin can delete.
     */
    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable String id, RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only delete your own events (admins can delete all).");
            return "redirect:/events";
        }
        eventService.delete(id);
        ra.addFlashAttribute("message", "Event deleted.");
        return "redirect:/events";
    }

    /**
     * GET /events/search
     * Shows the search form.
     */
    @GetMapping("/search")
    public String searchForm(Model model) {
        model.addAttribute("eventSearch", new EventSearch());
        model.addAttribute("currentUserId", currentUserId());
        return "searchForm";
    }

    /**
     * POST /events/search
     * Executes a simple search by description 
     * and shows the results on the events list page.
     */
    @PostMapping("/search")
    public String search(@ModelAttribute @Valid EventSearch eventSearch,
                         BindingResult result,
                         Model model) {
        if (result.hasErrors()) {
            return "searchForm";
        }
        List<EventModel> events = eventService.findByDescription(eventSearch.getSearchString());
        model.addAttribute("message", "Search results for " + eventSearch.getSearchString());
        model.addAttribute("events", events);
        model.addAttribute("currentUserId", currentUserId());
        return "events";
    }
}
