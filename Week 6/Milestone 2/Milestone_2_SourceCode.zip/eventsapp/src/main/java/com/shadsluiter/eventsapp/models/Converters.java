package com.shadsluiter.eventsapp.models;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Converters
 *
 * Centralized mapping methods between:
 * - *Entity classes (DB layer, use Long ids, java.sql.Date)
 * - *Model classes (web/API layer, use String ids, java.util.Date)
 *
 * Purpose in the milestone:
 * - Keeps mapping logic in one place instead of scattered across services/controllers.
 * - Demonstrates safe null/blank checks when converting ids.
 * - Handles conversion between sql.Date and util.Date for events.
 * - Ensures role sets are copied defensively so caller code cannot modify internal state.
 */
public final class Converters {

    private Converters() { }

    // ---------------------------------------------------------------------
    // Users
    // ---------------------------------------------------------------------

    /**
     * Convert a UserEntity (from DB) into a UserModel (for API/web).
     */
    public static UserModel userEntityToUserModel(UserEntity e) {
        if (e == null) return null;

        UserModel m = new UserModel();
        m.setId(e.getId() == null ? null : e.getId().toString());
        m.setUserName(e.getUserName());
        m.setPassword(e.getPassword());
        m.setEnabled(e.isEnabled());
        m.setAccountNonExpired(e.isAccountNonExpired());
        m.setCredentialsNonExpired(e.isCredentialsNonExpired());
        m.setAccountNonLocked(e.isAccountNonLocked());

        // Copy roles into a new set (avoid shared reference).
        if (e.getRoles() != null) {
            m.setRoles(new HashSet<>(e.getRoles()));
        } else {
            m.setRoles(new HashSet<>());
        }
        return m;
    }

    /**
     * Convert a UserModel (from web/API) into a UserEntity (for DB).
     * Includes safe parsing of String id into Long.
     */
    public static UserEntity userModelToUserEntity(UserModel m) {
        if (m == null) return null;

        UserEntity e = new UserEntity();

        // Null/blank safe conversion of id
        if (m.getId() != null && !m.getId().isBlank()) {
            e.setId(Long.parseLong(m.getId()));
        }

        e.setUserName(m.getUserName());
        e.setPassword(m.getPassword());
        e.setEnabled(m.isEnabled());
        e.setAccountNonExpired(m.isAccountNonExpired());
        e.setCredentialsNonExpired(m.isCredentialsNonExpired());
        e.setAccountNonLocked(m.isAccountNonLocked());

        // Copy roles or default to empty set
        Set<String> roles = m.getRoles();
        e.setRoles(roles != null ? new HashSet<>(roles) : new HashSet<>());

        return e;
    }

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    /**
     * Convert an EventEntity (from DB) into an EventModel (for API/web).
     * Handles conversion of sql.Date -> util.Date.
     */
    public static EventModel eventEntityToEventModel(EventEntity e) {
        if (e == null) return null;

        EventModel m = new EventModel();
        m.setId(e.getId() == null ? null : e.getId().toString());
        m.setName(e.getName());

        if (e.getDate() != null) {
            m.setDate(new java.util.Date(e.getDate().getTime()));
        } else {
            m.setDate(null);
        }

        m.setLocation(e.getLocation());
        m.setOrganizerid(e.getOrganizerid());
        m.setDescription(e.getDescription());
        return m;
    }

    /**
     * Convert an EventModel (from web/API) into an EventEntity (for DB).
     * Handles conversion of util.Date -> sql.Date.
     */
    public static EventEntity eventModelToEventEntity(EventModel m) {
        if (m == null) return null;

        EventEntity e = new EventEntity();

        // Null/blank safe conversion of id
        if (m.getId() != null && !m.getId().isBlank()) {
            e.setId(Long.parseLong(m.getId()));
        }

        e.setName(m.getName());

        if (m.getDate() != null) {
            e.setDate(new Date(m.getDate().getTime()));
        } else {
            e.setDate(null);
        }

        e.setLocation(m.getLocation());
        e.setOrganizerid(m.getOrganizerid());
        e.setDescription(m.getDescription());
        return e;
    }
}
