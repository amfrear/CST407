package com.shadsluiter.eventsapp.models; 

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * EventModel
 *
 * Web/API-facing representation of an event.
 *
 * Purpose in the milestone:
 * - Used by controllers (both MVC and REST) to pass event data to/from the view or API.
 * - Works with String ids for web-friendliness.
 * - Uses java.util.Date for easier binding with form inputs and JSON.
 *
 * Notes:
 * - Converted to/from EventEntity in the Converters class.
 * - organizerid ties back to the User who created the event.
 */
public class EventModel {

    private String id;          // String id (converted to Long in EventEntity)
    private String name;        // Event name

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date date;          // Event date (java.util.Date for web/API)

    private String location;    // Location of the event
    private String organizerid; // User id of the organizer
    private String description; // Details about the event

    public EventModel() {}

    public EventModel(String id, String name, Date date, String location, String organizerid, String description) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.location = location;
        this.organizerid = organizerid;
        this.description = description;
    }

    // ----- Getters and setters -----
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getOrganizerid() {
        return organizerid;
    }
    public void setOrganizerid(String organizerid) {
        this.organizerid = organizerid;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
