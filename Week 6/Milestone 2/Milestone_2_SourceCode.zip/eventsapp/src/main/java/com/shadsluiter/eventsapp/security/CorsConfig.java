package com.shadsluiter.eventsapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

/**
 * CorsConfig
 *
 * Configuration class for Cross-Origin Resource Sharing (CORS).
 *
 * Purpose in the milestone:
 * - Allows the front-end (running on localhost:5500) to call the back-end API.
 * - Demonstrates how to expose specific HTTP methods and headers for cross-origin requests.
 * - Registers these rules for all /api/** endpoints.
 */
@Configuration
public class CorsConfig {

    /**
     * Defines the CORS policy used by Spring Security.
     *
     * Allowed Origins:
     * - Local development front-end on localhost:5500 and 127.0.0.1:5500.
     *
     * Allowed Methods:
     * - GET, POST, PUT, DELETE, OPTIONS (covers common API operations).
     *
     * Allowed Headers:
     * - "Content-Type" for JSON bodies.
     * - "Authorization" for sending JWT tokens.
     *
     * Exposed Headers:
     * - "Location" header so the client can read it (useful after creating resources).
     *
     * AllowCredentials:
     * - False for now, since JWT tokens are sent in headers (not cookies).
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();

        cfg.setAllowedOrigins(Arrays.asList(
                "http://localhost:5500",
                "http://127.0.0.1:5500"
        ));
        cfg.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        cfg.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization"));
        cfg.setExposedHeaders(Arrays.asList("Location"));
        cfg.setAllowCredentials(false);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", cfg);
        return source;
    }
}
