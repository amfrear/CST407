package com.shadsluiter.eventsapp.models;

import java.sql.Date;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * EventEntity
 *
 * Database-facing representation of an event.
 *
 * Purpose in the milestone:
 * - Represents a row in the "events" table.
 * - Used by the repository layer when reading/writing events.
 * - Passed through the service layer to interact with controllers.
 *
 * Notes:
 * - Uses java.sql.Date for compatibility with SQL/JDBC.
 * - Organizerid is stored as a String (links back to a user id).
 */
public class EventEntity {

    private Long id;              // Primary key in DB
    private String name;          // Event name

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date date;            // Event date (SQL type for DB storage)

    private String location;      // Where the event takes place
    private String organizerid;   // User id of the organizer
    private String description;   // Extra details about the event

    public EventEntity() {}

    public EventEntity(Long id, String name, Date date, String location, String organizerid, String description) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.location = location;
        this.organizerid = organizerid;
        this.description = description;
    }

    // ----- Getters and setters -----
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getOrganizerid() {
        return organizerid;
    }
    public void setOrganizerid(String organizerid) {
        this.organizerid = organizerid;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
