package com.shadsluiter.eventsapp.models;

import java.util.Set;

/**
 * UserModel
 *
 * Web/API-facing representation of a user.
 *
 * Purpose in the milestone:
 * - Used by controllers (REST + MVC) to send/receive user data.
 * - Works with String id for flexibility (e.g., easier JSON, cross-database use).
 * - Exposes account status flags (enabled, expired, locked) for integration with security.
 * - Roles are stored as a Set<String> (e.g., ROLE_USER, ROLE_ADMIN).
 *
 * Notes:
 * - Converted to/from UserEntity using the Converters class.
 * - Entity uses Long for id (DB), model uses String for id (web/API).
 */
public class UserModel {

    private String id;                  // String id (converted from Long in UserEntity)
    private String userName;            // Login name
    private String password;            // Plain on input; encoded before saving
    private boolean enabled;            // Account active status
    private boolean accountNonExpired;  // Account expiration flag
    private boolean credentialsNonExpired; // Credential expiration flag
    private boolean accountNonLocked;   // Lockout flag
    private Set<String> roles;          // User roles (e.g., ROLE_USER, ROLE_ADMIN)

    // ----- Constructors -----
    public UserModel() {
    }

    public UserModel(String id, String userName, String password,
                     boolean enabled, boolean accountNonExpired,
                     boolean credentialsNonExpired, boolean accountNonLocked,
                     Set<String> roles) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.enabled = enabled;
        this.accountNonExpired = accountNonExpired;
        this.credentialsNonExpired = credentialsNonExpired;
        this.accountNonLocked = accountNonLocked;
        this.roles = roles;
    }

    // ----- Getters and setters -----
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }
    public void setAccountNonExpired(boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }
    public void setCredentialsNonExpired(boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }
    public void setAccountNonLocked(boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    public Set<String> getRoles() {
        return roles;
    }
    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }
}
