package com.shadsluiter.ordersapp.service;

import com.shadsluiter.ordersapp.data.OrderRepository;
import com.shadsluiter.ordersapp.data.OrderRepositoryInterface;
import com.shadsluiter.ordersapp.models.OrderEntity;
import com.shadsluiter.ordersapp.models.OrderModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepositoryInterface orderRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<OrderModel> findAll() {
        List<OrderEntity> orderEntities = orderRepository.findAll();
        return convertToModels(orderEntities);

    }

    public List<OrderModel> findByCustomerid(String customerid) {
        List<OrderEntity> orderEntities = orderRepository.findByCustomerid(Long.valueOf(customerid));
        return convertToModels(orderEntities);
    }

    public List<OrderModel> findByNotes(String searchString) {
        List<OrderEntity> orderEntities = orderRepository.findByNote(searchString);
        return convertToModels(orderEntities);
    }

    public OrderModel save(OrderModel order) {
        OrderEntity orderEntity = convertToEntity(order);
        OrderEntity savedOrder = orderRepository.save(orderEntity);
        return convertToModel(savedOrder);
    }

    public void delete(String id) {
        orderRepository.deleteById(Long.valueOf(id));
    }

    public OrderModel updateOrder(String id, OrderModel order) {
        order.setId(id);
        return save(order);
    }

    public OrderModel findById(String id) {
        OrderEntity orderEntity = orderRepository.findById(Long.valueOf(id));
        return convertToModel(orderEntity);
    }

    private List<OrderModel> convertToModels(List<OrderEntity> orderEntities) {
        List<OrderModel> orderModels = new ArrayList<>();
        for (OrderEntity orderEntity : orderEntities) {
            orderModels.add(convertToModel(orderEntity));
        }
        return orderModels;
    }

    private OrderModel convertToModel(OrderEntity orderEntity) {
        return new OrderModel(
                orderEntity.getId().toString(),
                orderEntity.getDate(),
                orderEntity.getCustomerid().toString(),
                orderEntity.getNotes()
        );
    }

    private List<OrderEntity> convertToEntities(List<OrderModel> orderModels) {
        List<OrderEntity> orderEntities = new ArrayList<>();
        for (OrderModel orderModel : orderModels) {
            orderEntities.add(convertToEntity(orderModel));
        }
        return orderEntities;
    }

    private OrderEntity convertToEntity(OrderModel orderModel) {
        OrderEntity orderEntity = new OrderEntity();
        if (orderModel.getId() != null) {
            orderEntity.setId(Long.parseLong(orderModel.getId()));
        }
        orderEntity.setDate(orderModel.getDate());
        orderEntity.setCustomerid(orderModel.getCustomerid());
        orderEntity.setNotes(orderModel.getNotes());
        return orderEntity;
    }


}
