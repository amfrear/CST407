package com.shadsluiter.ordersapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            // keep things simple while wiring forms for this activity
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth
                // public pages/resources
                .requestMatchers(
                    "/",                         // home
                    "/users/register",           // register page
                    "/users/loginForm",          // custom login page
                    "/access-denied",            // ✅ custom 403 page (must be public)
                    "/css/**", "/js/**", "/images/**"
                ).permitAll()

                // ADMIN-only actions
                .requestMatchers(
                    "/orders/create",
                    "/orders/edit/**",
                    "/orders/delete/**"
                ).hasRole("ADMIN")

                // authenticated users (USER or ADMIN) can view order pages
                .requestMatchers("/orders/**").hasAnyRole("USER", "ADMIN")

                // everything else requires authentication
                .anyRequest().authenticated()
            )

            // custom login
            .formLogin(form -> form
                .loginPage("/users/loginForm")        // show login.html
                .loginProcessingUrl("/login")         // form POST target
                .defaultSuccessUrl("/orders", true)   // go to orders on success
                .failureUrl("/users/loginForm?error") // show error on failure
                .permitAll()
            )

            // logout
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
            )

            .exceptionHandling(ex -> ex.accessDeniedPage("/access-denied"));

        return http.build();
    }
}
