package com.shadsluiter.ordersapp.data;

import com.shadsluiter.ordersapp.models.OrderEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

@Repository
public class OrderRepository implements OrderRepositoryInterface {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public OrderRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<OrderEntity> findByCustomerid(Long customerid) {
        String sql = "SELECT * FROM orders WHERE customerid = " + customerid;
         List<OrderEntity> result =  jdbcTemplate.query(sql, new OrderModelRowMapper());
            return result;
    }

    @Override
    public List<OrderEntity> findAll() {
        String sql = "SELECT * FROM orders";
        return jdbcTemplate.query(sql, new OrderModelRowMapper());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM orders WHERE id = " + id;
        jdbcTemplate.update(sql);
    }

  
    @Override
public OrderEntity save(OrderEntity order) {
    // Format the date to the correct SQL 'datetime' format
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String formattedDate = dateFormat.format(order.getDate());

    if (order.getId() == null) {
        // Insert new order
        String sql = "INSERT INTO orders (date, customerid, notes) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, formattedDate, order.getCustomerid(), order.getNotes());
        Long id = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        order.setId(id);
    } else {
        // Update existing order
        String sql = "UPDATE orders SET date = ?, customerid = ?, notes = ? WHERE id = ?";
        jdbcTemplate.update(sql, formattedDate, order.getCustomerid(), order.getNotes(), order.getId());
    }
    return order;
}

    @Override
    public OrderEntity findById(Long id) {
        String sql = "SELECT * FROM orders WHERE id = " + id;
        return jdbcTemplate.queryForObject(sql, new OrderModelRowMapper());
    }

    @Override
    public boolean existsById(Long id) {
        String sql = "SELECT COUNT(*) FROM orders WHERE id = " + id;
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null && count > 0;
    }

    @Override
    public long count() {
        String sql = "SELECT COUNT(*) FROM orders";
        Long result = jdbcTemplate.queryForObject(sql, Long.class);
        if (result == null) {
            return 0;
        }
        return result;
    }

    @Override
    public void delete(OrderEntity order) {
        deleteById(order.getId());
    }

    @Override
    public void deleteAll() {
        String sql = "DELETE FROM orders";
        jdbcTemplate.update(sql);
    }

    @Override
    public void deleteAll(Iterable<? extends OrderEntity> orders) {
        for (OrderEntity order : orders) {
            delete(order);
        }
    }
 

    @Override
    public List<OrderEntity> saveAll(Iterable<OrderEntity> orders) {
        for (OrderEntity order : orders) {
            save(order);
        }
        return (List<OrderEntity>) orders;
    }

    private static class OrderModelRowMapper implements RowMapper<OrderEntity> {
        @Override
        public OrderEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
            OrderEntity order = new OrderEntity();
            order.setId(rs.getLong("id"));
            order.setDate(rs.getDate("date"));
            order.setCustomerid(rs.getString("customerid"));
            order.setNotes(rs.getString("notes"));
            return order;
        }
    }

    @Override
    public List<OrderEntity> findByNote(String name) {
        String sql = "SELECT * FROM orders WHERE notes LIKE '%" + name + "%'";
        return jdbcTemplate.query(sql, new OrderModelRowMapper());
    }
}
