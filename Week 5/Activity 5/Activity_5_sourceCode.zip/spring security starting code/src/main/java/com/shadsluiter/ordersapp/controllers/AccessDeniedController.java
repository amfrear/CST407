package com.shadsluiter.ordersapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AccessDeniedController {

    @GetMapping("/access-denied")
    public String accessDenied() {
        // resolves to templates/access-denied.html
        return "access-denied";
    }
}
