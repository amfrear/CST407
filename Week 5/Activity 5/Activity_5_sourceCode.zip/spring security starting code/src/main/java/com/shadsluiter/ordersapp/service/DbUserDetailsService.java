package com.shadsluiter.ordersapp.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;

@Service
public class DbUserDetailsService implements UserDetailsService {

    private final JdbcTemplate jdbc;

    public DbUserDetailsService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // users table: id, login_name, password, enabled, account_non_expired, credentials_non_expired, account_non_locked
        var user = jdbc.query(
                "SELECT id, login_name, password, enabled, account_non_expired, credentials_non_expired, account_non_locked " +
                "FROM users WHERE login_name = ?",
                rs -> rs.next() ? new DbUser(
                        rs.getLong("id"),
                        rs.getString("login_name"),
                        rs.getString("password"),
                        rs.getBoolean("enabled"),
                        rs.getBoolean("account_non_expired"),
                        rs.getBoolean("credentials_non_expired"),
                        rs.getBoolean("account_non_locked")
                ) : null,
                username
        );

        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }

        // roles table: id, role, user_id
        List<GrantedAuthority> authorities = jdbc.query(
                "SELECT role FROM roles WHERE user_id = ?",
                (rs, rowNum) -> new SimpleGrantedAuthority(rs.getString("role")),
                user.id()
        );

        return org.springframework.security.core.userdetails.User
                .withUsername(user.loginName())
                .password(user.password())        // already encoded for users like 'root'
                .authorities(authorities)
                .accountExpired(!user.accountNonExpired())
                .accountLocked(!user.accountNonLocked())
                .credentialsExpired(!user.credentialsNonExpired())
                .disabled(!user.enabled())
                .build();
    }

    // simple record to hold DB row
    private record DbUser(
            long id, String loginName, String password,
            boolean enabled, boolean accountNonExpired,
            boolean credentialsNonExpired, boolean accountNonLocked) {}
}
