package com.shadsluiter.ordersapp.service;

import com.shadsluiter.ordersapp.data.UserRepository;
import com.shadsluiter.ordersapp.models.UserEntity;
import com.shadsluiter.ordersapp.models.UserModel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /** Create or update a user.
     *  IMPORTANT: encodes plaintext passwords using BCrypt before saving. */
    public UserModel save(UserModel userModel) {
        UserEntity userEntity = convertToEntity(userModel);

        // Encode only if it's not already a BCrypt hash (avoid double-encoding).
        String rawOrEncoded = userEntity.getPassword();
        if (rawOrEncoded != null && !isBcryptHash(rawOrEncoded)) {
            userEntity.setPassword(passwordEncoder.encode(rawOrEncoded));
        }

        UserEntity savedUser = userRepository.save(userEntity);
        return convertToModel(savedUser);
    }

    // Spring Security will eventually call our UserDetailsService;
    // keeping this for any existing code paths.
    public UserModel findByLoginName(String loginName) {
        UserEntity userEntity = userRepository.findByLoginName(loginName);
        if (userEntity == null) return null;
        return convertToModel(userEntity);
    }

    /** Use the PasswordEncoder to compare a raw password to the stored hash. */
    public boolean verifyPassword(UserModel user) {
        UserEntity userEntity = userRepository.findByLoginName(user.getUserName());
        if (userEntity == null) return false;
        return passwordEncoder.matches(user.getPassword(), userEntity.getPassword());
    }

    public UserModel findById(String id) {
        UserEntity userEntity = userRepository.findById(Long.parseLong(id));
        return convertToModel(userEntity);
    }

    public void delete(String id) {
        userRepository.deleteById(Long.parseLong(id));
    }

    public List<UserModel> findAll() {
        List<UserEntity> userEntities = userRepository.findAll();
        return convertToModels(userEntities);
    }

    // ---------- helpers ----------

    private boolean isBcryptHash(String val) {
        // Basic check for BCrypt prefixes produced by Spring Security encoders
        return val.startsWith("$2a$") || val.startsWith("$2b$") || val.startsWith("$2y$");
    }

    private List<UserModel> convertToModels(List<UserEntity> userEntities) {
        List<UserModel> userModels = new ArrayList<>();
        for (UserEntity userEntity : userEntities) {
            userModels.add(convertToModel(userEntity));
        }
        return userModels;
    }

    private UserModel convertToModel(UserEntity userEntity) {
        UserModel userModel = new UserModel();
        userModel.setId(userEntity.getId().toString());
        userModel.setUserName(userEntity.getUserName());
        userModel.setPassword(userEntity.getPassword());
        userModel.setEnabled(userEntity.isEnabled());
        userModel.setAccountNonExpired(userEntity.isAccountNonExpired());
        userModel.setCredentialsNonExpired(userEntity.isCredentialsNonExpired());
        userModel.setAccountNonLocked(userEntity.isAccountNonLocked());
        userModel.setRoles(userEntity.getRoles());
        return userModel;
    }

    private UserEntity convertToEntity(UserModel userModel) {
        UserEntity userEntity = new UserEntity();
        if (userModel.getId() != null) {
            userEntity.setId(Long.parseLong(userModel.getId()));
        }
        userEntity.setUserName(userModel.getUserName());
        userEntity.setPassword(userModel.getPassword()); // encoded in save(...)
        userEntity.setEnabled(userModel.isEnabled());
        userEntity.setAccountNonExpired(userModel.isAccountNonExpired());
        userEntity.setCredentialsNonExpired(userModel.isCredentialsNonExpired());
        userEntity.setAccountNonLocked(userModel.isAccountNonLocked());
        userEntity.setRoles(userModel.getRoles());
        return userEntity;
    }
}
