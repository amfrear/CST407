package com.shadsluiter.ordersapp.controllers;

import com.shadsluiter.ordersapp.models.OrderModel;
import com.shadsluiter.ordersapp.models.OrderSearch;
import com.shadsluiter.ordersapp.service.OrderService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import org.springframework.security.access.prepost.PreAuthorize;   // ✅ add this for method security

import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrdersController {

    // orderService allows the controller to interact with the database and orders table
    private final OrderService orderService;

    // inject the orderService into the controller using constructor injection
    @Autowired
    public OrdersController(OrderService orderService) {
        this.orderService = orderService;
    }

    // get all orders from the database and display them in orders.html
    @GetMapping
    public String getAllOrders(Model model) {
        List<OrderModel> orders = orderService.findAll();
        model.addAttribute("orders", orders);
        model.addAttribute("message", "Showing all orders");
        model.addAttribute("pageTitle", "Orders");
        return "orders";
    }

    // search form for orders
    @GetMapping("/search")
    public String searchForm(Model model) {
        model.addAttribute("orderSearch", new OrderSearch());
        return "searchForm";
    }

    // process search
    @PostMapping("/search")
    public String search(@ModelAttribute @Valid OrderSearch orderSearch, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "searchForm";
        }
        List<OrderModel> orders = orderService.findByNotes(orderSearch.getSearchString());
        model.addAttribute("message", "Search results for " + orderSearch.getSearchString());
        model.addAttribute("orders", orders);
        return "orders";
    }

    // ===================== ADMIN-ONLY =====================

    // show the create order form
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/create")
    public String showCreateOrderForm(Model model) {
        model.addAttribute("order", new OrderModel());
        model.addAttribute("pageTitle", "Create Order");
        return "create-order";
    }

    // process the form submission and save the order to the database
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create")
    public String createOrder(@ModelAttribute @Valid OrderModel order, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", "Create Order");
            return "create-order";
        }
        orderService.save(order);
        return "redirect:/orders";
    }

    // show the edit order form
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/edit/{id}")
    public String showEditOrderForm(@PathVariable String id, Model model) {
        OrderModel order = orderService.findById(id);
        model.addAttribute("order", order);
        return "edit-order";
    }

    // process the form submission and update the order in the database
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/edit/{id}")
    public String updateOrder(@PathVariable String id, @ModelAttribute OrderModel order, Model model) {
        OrderModel updatedOrder = orderService.updateOrder(id, order);
        model.addAttribute("order", updatedOrder);
        return "redirect:/orders";
    }

    // delete the order from the database
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable String id) {
        orderService.delete(id);
        return "redirect:/orders";
    }
}
