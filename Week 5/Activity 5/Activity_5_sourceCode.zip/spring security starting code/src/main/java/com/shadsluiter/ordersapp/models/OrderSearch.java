package com.shadsluiter.ordersapp.models;

public class OrderSearch {
    private String searchString;

    public OrderSearch() {
        searchString = "";
    }

    public OrderSearch(String searchString) {
        this.searchString = searchString;
    }

    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }  
    
}
