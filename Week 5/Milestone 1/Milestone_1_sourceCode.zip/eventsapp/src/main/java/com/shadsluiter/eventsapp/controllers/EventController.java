package com.shadsluiter.eventsapp.controllers;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shadsluiter.eventsapp.models.EventModel;
import com.shadsluiter.eventsapp.models.EventSearch;
import com.shadsluiter.eventsapp.models.UserModel;
import com.shadsluiter.eventsapp.service.EventService;
import com.shadsluiter.eventsapp.service.UserService;

// Controller handling all /events routes.
// Duties:
// - Render event list, create/edit forms, and search form.
// - Enforce simple access rules (owner or admin) for edit/delete.
// - Bind and validate form inputs.
// - Ensure organizer is set to the authenticated user on create/update.
@Controller
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;
    private final UserService userService;

    @Autowired
    public EventController(EventService eventService, UserService userService) {
        // Constructor injection keeps dependencies final and test-friendly.
        this.eventService = eventService;
        this.userService = userService;
    }

    // ---------- helpers ----------

    // Returns the authenticated user's id (String), or null if anonymous.
    // Used by views (owner-only UI) and by create/update to stamp ownership.
    private String currentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            return null;
        }
        // auth.getName() is the login name; lookup user record to get its id.
        UserModel u = userService.findByLoginName(auth.getName());
        return (u != null) ? u.getId() : null;
    }

    // Returns true if the authenticated user has ROLE_ADMIN.
    // Admins can edit/delete any event.
    private boolean isAdmin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            return false;
        }
        for (GrantedAuthority a : auth.getAuthorities()) {
            if ("ROLE_ADMIN".equals(a.getAuthority())) return true;
        }
        return false;
    }

    // Returns true if the authenticated user is the owner of the given event.
    // Ownership check compares String ids. Returns false for missing event or anonymous user.
    private boolean isOwner(String eventId) {
        EventModel ev = eventService.findById(eventId);
        String me = currentUserId();
        return ev != null && me != null && me.equals(ev.getOrganizerid());
    }
    // -----------------------------

    // GET /events
    // Renders the full list of events.
    // Model attributes:
    // - "events": list to display
    // - "message": optional banner text
    // - "pageTitle": page heading
    // - "currentUserId": enables owner-only buttons in the template
    @GetMapping
    public String getAllEvents(Model model) {
        List<EventModel> events = eventService.findAll();
        model.addAttribute("events", events);
        model.addAttribute("message", "Showing all events");
        model.addAttribute("pageTitle", "Events");
        model.addAttribute("currentUserId", currentUserId()); // used by the view to conditionally show controls
        return "events"; // templates/events.html
    }

    // GET /events/create
    // Displays a blank "Create Event" form.
    // Provides an empty EventModel for form binding and an optional user list if the form requires it.
    @GetMapping("/create")
    public String showCreateEventForm(Model model) {
        model.addAttribute("event", new EventModel());
        model.addAttribute("pageTitle", "Create Event");

        List<UserModel> users = userService.findAll();  // keep if the form includes a user selector
        model.addAttribute("users", users);

        return "create-event";
    }

    // POST /events/create
    // Handles creation form submission.
    // Validation:
    // - @Valid triggers bean validation; BindingResult holds errors.
    // On error: re-render the form with validation feedback.
    // Security:
    // - Organizer id is forced to the authenticated user to prevent client-side spoofing.
    @PostMapping("/create")
    public String createEvent(@ModelAttribute @Valid EventModel event,
                              BindingResult result,
                              Model model,
                              RedirectAttributes ra) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", "Create Event");
            List<UserModel> users = userService.findAll();
            model.addAttribute("users", users);
            return "create-event";
        }

        // Enforce ownership by the authenticated user (if any).
        String me = currentUserId();
        if (me != null) {
            event.setOrganizerid(me);
        }

        eventService.save(event);
        ra.addFlashAttribute("message", "Event created.");
        return "redirect:/events"; // PRG pattern to avoid resubmission on refresh
    }

    // GET /events/edit/{id}
    // Displays the edit form for an existing event.
    // Access control:
    // - Only the owner or an admin is allowed to access this form.
    // Missing event handling (null) can be customized if needed.
    @GetMapping("/edit/{id}")
    public String showEditEventForm(@PathVariable String id,
                                    Model model,
                                    RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only edit your own events (admins can edit all).");
            return "redirect:/events";
        }

        EventModel event = eventService.findById(id);
        model.addAttribute("event", event);

        List<UserModel> users = userService.findAll();
        model.addAttribute("users", users);

        return "edit-event";
    }

    // POST /events/edit/{id}
    // Applies updates to an existing event.
    // Access control: owner or admin only.
    // Validation: on error, re-render the form with the provided data.
    // Ownership rule:
    // - Organizer id is kept as the authenticated user to block reassignment via form tampering.
    //   To preserve original owner during admin edits, load current record and copy organizerid.
    @PostMapping("/edit/{id}")
    public String updateEvent(@PathVariable String id,
                              @ModelAttribute EventModel event,
                              BindingResult result,
                              Model model,
                              RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only edit your own events (admins can edit all).");
            return "redirect:/events";
        }

        if (result.hasErrors()) {
            model.addAttribute("event", event);
            List<UserModel> users = userService.findAll();
            model.addAttribute("users", users);
            return "edit-event";
        }

        // Enforce ownership by the authenticated user (optional for admins, depending on policy).
        String me = currentUserId();
        if (me != null) {
            event.setOrganizerid(me);
        }

        eventService.updateEvent(id, event);
        ra.addFlashAttribute("message", "Event updated.");
        return "redirect:/events";
    }

    // GET /events/delete/{id}
    // Deletes an event.
    // Note: Implemented as GET to match existing template. For production, prefer POST/DELETE with CSRF protection.
    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable String id, RedirectAttributes ra) {
        if (!isOwner(id) && !isAdmin()) {
            ra.addFlashAttribute("message", "You can only delete your own events (admins can delete all).");
            return "redirect:/events";
        }
        eventService.delete(id);
        ra.addFlashAttribute("message", "Event deleted.");
        return "redirect:/events";
    }

    // GET /events/search
    // Renders the search form.
    // Supplies an empty EventSearch for form binding and currentUserId for owner-only UI handling on results.
    @GetMapping("/search")
    public String searchForm(Model model) {
        model.addAttribute("eventSearch", new EventSearch());
        model.addAttribute("currentUserId", currentUserId());
        return "searchForm";
    }

    // POST /events/search
    // Executes a simple search by description and reuses the list view to show results.
    // On validation error: re-render the search form.
    // Adds a message describing the query to the model for user feedback.
    @PostMapping("/search")
    public String search(@ModelAttribute @Valid EventSearch eventSearch,
                         BindingResult result,
                         Model model) {
        if (result.hasErrors()) {
            return "searchForm";
        }
        List<EventModel> events = eventService.findByDescription(eventSearch.getSearchString());
        model.addAttribute("message", "Search results for " + eventSearch.getSearchString());
        model.addAttribute("events", events);
        model.addAttribute("currentUserId", currentUserId());
        return "events";
    }
}
