package com.shadsluiter.eventsapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

  // Application-provided UserDetailsService (loads users/roles from persistence layer)
  private final UserDetailsService userDetailsService;

  public SecurityConfig(UserDetailsService userDetailsService) {
    this.userDetailsService = userDetailsService;
  }

  // Password hashing strategy (BCrypt). Must match how passwords are stored.
  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  // Authentication provider that uses the UserDetailsService + PasswordEncoder.
  // Validates credentials by loading the user and comparing the hashed password.
  @Bean
  public DaoAuthenticationProvider daoAuthenticationProvider() {
    var p = new DaoAuthenticationProvider();
    p.setUserDetailsService(userDetailsService);
    p.setPasswordEncoder(passwordEncoder());
    return p;
  }

  // Main HTTP security configuration: URL authorization, login, logout, CSRF, and auth provider.
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http
      .authorizeHttpRequests(auth -> auth
        // Public pages and static assets (no authentication required)
        .requestMatchers("/", "/users/", "/users/register", "/users/register/**",
                         "/users/loginForm", "/css/**", "/js/**", "/images/**", "/webjars/**").permitAll()
        // Anyone can view/search events
        .requestMatchers("/events", "/events/search", "/events/search/**").permitAll()
        // Auth required for any state-changing event endpoints
        .requestMatchers("/events/create", "/events/edit/**", "/events/delete/**").authenticated()
        // Fallback: allow anything else (tighten as needed)
        .anyRequest().permitAll()
      )
      // HTML form-based login configuration
      .formLogin(form -> form
        .loginPage("/users/loginForm")       // Custom login page (GET)
        .loginProcessingUrl("/login")        // Endpoint that processes credentials (POST handled by Spring Security)
        .usernameParameter("userName")       // Must match the 'name' attribute in the login form
        .passwordParameter("password")
        .defaultSuccessUrl("/events", true)  // Always redirect here after successful login
        .failureUrl("/users/loginForm?error")// Redirect with error flag on failure
        .permitAll()
      )
      // Logout configuration
      .logout(logout -> logout
        .logoutUrl("/logout")                    // Invalidate session + clear auth on POST to /logout
        .logoutSuccessUrl("/users/loginForm?logout")
        .permitAll()
      )
      // Register DAO-based authentication provider
      .authenticationProvider(daoAuthenticationProvider())
      // CSRF disabled for simplicity in this milestone.
      // For production and any POST/PUT/DELETE forms, CSRF should be enabled and tokens included in forms.
      .csrf(csrf -> csrf.disable());

    return http.build();
  }
}
