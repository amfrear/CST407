package com.shadsluiter.eventsapp.security;

import com.shadsluiter.eventsapp.data.UserRepository;
import com.shadsluiter.eventsapp.models.UserEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.stream.Collectors;

@Service
public class CustomUserDetailsService implements UserDetailsService {

  // Repository used to load user records (credentials + roles) from persistence layer
  private final UserRepository userRepository;

  public CustomUserDetailsService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  // Core entry point used by Spring Security during authentication.
  // Receives the submitted username (as configured by usernameParameter in SecurityConfig),
  // loads the user, maps roles to GrantedAuthority, and returns a framework UserDetails.
  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    // Lookup by login name. Ensure this aligns with the login form field and SecurityConfig.
    // Example: if SecurityConfig uses .usernameParameter("userName"), the submitted value
    // will arrive here as 'username' and must correspond to findByLoginName(...) lookup.
    UserEntity u = userRepository.findByLoginName(username);
    if (u == null) throw new UsernameNotFoundException("User not found: " + username);

    // Convert domain roles (e.g., "ROLE_ADMIN") to GrantedAuthority objects.
    // Role strings should include the "ROLE_" prefix for role-based matches like hasRole("ADMIN").
    Collection<? extends GrantedAuthority> authorities = u.getRoles().stream()
        .map(SimpleGrantedAuthority::new)
        .collect(Collectors.toList());

    // Build a Spring Security UserDetails instance from the domain entity.
    // Username: value exposed to SecurityContext#getAuthentication().getName()
    // Password: must already be encoded using the configured PasswordEncoder (e.g., BCrypt).
    // Flags: control account status (enabled, non-expired, non-locked, credentials non-expired).
    return new org.springframework.security.core.userdetails.User(
        u.getUserName(),                 // principal username shown in SecurityContext
        u.getPassword(),                 // encoded password
        u.isEnabled(),                   // enabled
        u.isAccountNonExpired(),         // accountNonExpired
        u.isCredentialsNonExpired(),     // credentialsNonExpired
        u.isAccountNonLocked(),          // accountNonLocked
        authorities                      // authorities derived from roles
    );
  }
}
