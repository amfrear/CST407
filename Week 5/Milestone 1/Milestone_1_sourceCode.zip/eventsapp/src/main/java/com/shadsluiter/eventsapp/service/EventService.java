package com.shadsluiter.eventsapp.service;

import com.shadsluiter.eventsapp.data.EventRepositoryInterface;
import com.shadsluiter.eventsapp.models.EventEntity;
import com.shadsluiter.eventsapp.models.EventModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat; // unused; can be removed
import java.util.ArrayList;
import java.util.List;

import java.sql.Date;              // unused due to fully-qualified usage below; can be removed
import java.text.SimpleDateFormat; // duplicate import; can be removed

@Service
public class EventService {

    // Repository abstraction for persistence operations (find/save/delete).
    // Keeps controllers decoupled from data access details.
    private final EventRepositoryInterface eventRepository;

    @Autowired
    public EventService(EventRepositoryInterface eventRepository) {
        this.eventRepository = eventRepository;
    }

    // Retrieve all events from the database and map entities -> models for the web layer.
    public List<EventModel> findAll() {
        List<EventEntity> eventEntities = eventRepository.findAll();
        return convertToModels(eventEntities);
    }

    // Retrieve events by organizer id (incoming id is a String in the web layer; repository expects Long).
    // Note: Long.valueOf(...) will throw NumberFormatException on non-numeric input; caller is trusted here.
    public List<EventModel> findByOrganizerid(String organizerid) {
        List<EventEntity> eventEntities = eventRepository.findByOrganizerid(Long.valueOf(organizerid));
        return convertToModels(eventEntities);
    }

    // Create or update an event based on the provided EventModel.
    // Flow: model -> entity, save via repository, entity -> model.
    public EventModel save(EventModel event) {
        EventEntity eventEntity = convertToEntity(event);
        EventEntity savedEvent = eventRepository.save(eventEntity);
        return convertToModel(savedEvent);
    }

    // Delete an event by id (String -> Long).
    public void delete(String id) {
        eventRepository.deleteById(Long.valueOf(id));
    }

    // Update an event by id: set the id on the incoming model and delegate to save(...).
    // Behavior depends on repository implementation:
    // - If id exists: update.
    // - If id does not exist: may insert a new row (upsert-like behavior).
    // Consider checking existence when strict update semantics are required.
    public EventModel updateEvent(String id, EventModel event) {
        event.setId(id);
        return save(event);
    }

    // Find a single event by id and map to model.
    // Repository method returns EventEntity directly (null if not found); adjust if using Optional in the future.
    public EventModel findById(String id) {
        EventEntity eventEntity = eventRepository.findById(Long.valueOf(id));
        return convertToModel(eventEntity);
    }

    // Helper: map a list of entities to a list of models.
    // Uses a simple loop for clarity; a stream map(...) would also work.
    private List<EventModel> convertToModels(List<EventEntity> eventEntities) {
        List<EventModel> eventModels = new ArrayList<>();
        for (EventEntity eventEntity : eventEntities) {
            eventModels.add(convertToModel(eventEntity));
        }
        return eventModels;
    }

    // Helper: map a single entity to a model (web-facing DTO).
    private EventModel convertToModel(EventEntity eventEntity) {
        return new EventModel(
                eventEntity.getId().toString(), // normalize id to String for controllers/views
                eventEntity.getName(),
                eventEntity.getDate(),          // java.sql.Date (see note in convertToEntity)
                eventEntity.getLocation(),
                eventEntity.getOrganizerid(),   // stored as String in entity/model
                eventEntity.getDescription()
        );
    }

    // Helper: map a model (from web layer) to a persistence entity.
    // Notes:
    // - Id parsing is conditional to support both create (null id) and update (non-null id).
    // - Date conversion uses java.sql.Date for JDBC; consider java.time (LocalDate/LocalDateTime) long-term.
    private EventEntity convertToEntity(EventModel eventModel) {
        EventEntity eventEntity = new EventEntity();
        
        if (eventModel.getId() != null) {
            eventEntity.setId(Long.parseLong(eventModel.getId())); // may throw NumberFormatException if invalid
        }
        
        eventEntity.setName(eventModel.getName());
    
        // Convert java.util.Date (from model) to java.sql.Date for JDBC compatibility.
        // Potential TZ considerations exist when mixing util/sql dates; prefer java.time API where possible.
        eventEntity.setDate(new java.sql.Date(eventModel.getDate().getTime()));
    
        eventEntity.setLocation(eventModel.getLocation());
        eventEntity.setOrganizerid(eventModel.getOrganizerid());
        eventEntity.setDescription(eventModel.getDescription());
        
        return eventEntity;
    }
    
    // Search events by description. Delegates to repository and maps results to models.
    public List<EventModel> findByDescription(String searchString) {
        List<EventEntity> eventEntities = eventRepository.findByDescription(searchString);
        return convertToModels(eventEntities);  
    }
}
