package com.shadsluiter.eventsapp.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shadsluiter.eventsapp.models.UserModel;
import com.shadsluiter.eventsapp.service.UserService;

@Controller
@RequestMapping("/users")
public class UsersController {

    private static final Logger log = LoggerFactory.getLogger(UsersController.class);

    private final UserService userService;

    public UsersController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String home() {
        return "home";
    }

    // --- LOGIN (view only; POST /login handled by Spring Security) ---
    @GetMapping("/loginForm")
    public String showLoginForm(Model model) {
        // Login form posts raw fields: userName + password, so a backing object isn't required.
        // Keep pageTitle if your template uses it.
        model.addAttribute("pageTitle", "Login");
        return "login";
    }

    // --- REGISTER (page + submit) ---
    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam("userName") String userName,
                           @RequestParam("password") String password,
                           Model model,
                           RedirectAttributes ra) {

        // basic validation
        if (userName == null || userName.isBlank() || password == null || password.isBlank()) {
            model.addAttribute("error", "Username and password are required.");
            return "register";
        }

        // duplicate check
        var existing = userService.findByLoginName(userName);
        if (existing != null) {
            model.addAttribute("error", "That username is already taken.");
            return "register";
        }

        // create + save (UserService encodes password, sets ROLE_USER, etc.)
        var user = new UserModel();
        user.setUserName(userName);
        user.setPassword(password);
        user.setEnabled(true);
        user.setAccountNonExpired(true);
        user.setCredentialsNonExpired(true);
        user.setAccountNonLocked(true);

        userService.save(user);
        log.info("User registered: {}", userName);

        // bounce to login with success banner
        return "redirect:/users/loginForm?registered";
    }

    // No explicit /users/logout mapping here.
    // Use Spring Security's /logout endpoint in your navbar: <a th:href="@{/logout}">Logout</a>
}
