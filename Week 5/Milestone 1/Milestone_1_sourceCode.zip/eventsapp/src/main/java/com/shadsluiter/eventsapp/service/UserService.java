package com.shadsluiter.eventsapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.shadsluiter.eventsapp.data.UserRepository;
import com.shadsluiter.eventsapp.models.UserEntity;
import com.shadsluiter.eventsapp.models.UserModel;

@Service
public class UserService {

    // Persistence gateway for UserEntity records.
    private final UserRepository userRepository;

    // Password hashing/verification strategy (e.g., BCrypt).
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Create or update a user.
    // Steps:
    // 1) Map model -> entity.
    // 2) Ensure password is encoded (idempotent: skip if already BCrypt).
    // 3) Ensure at least a base role (ROLE_USER).
    // 4) For new users (no id), set sensible account flags.
    // 5) Save and map back to model.
    public UserModel save(UserModel userModel) {
        UserEntity userEntity = convertToEntity(userModel);

        // Encode password if not already BCrypt (simple prefix check).
        if (!isBcrypt(userEntity.getPassword())) {
            userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword()));
        }

        // Ensure at least one role is present.
        if (userEntity.getRoles() == null || userEntity.getRoles().isEmpty()) {
            Set<String> roles = new HashSet<>();
            roles.add("ROLE_USER");
            userEntity.setRoles(roles);
        }

        // Default account flags for new users.
        if (userEntity.getId() == null) {
            userEntity.setEnabled(true);
            userEntity.setAccountNonExpired(true);
            userEntity.setCredentialsNonExpired(true);
            userEntity.setAccountNonLocked(true);
        }

        UserEntity savedUser = userRepository.save(userEntity);
        return convertToModel(savedUser);
    }

    // Lookup by login name for non-security use cases.
    // Note: Authentication should rely on
    // CustomUserDetailsService.loadUserByUsername.
    public UserModel findByLoginName(String loginName) {
        UserEntity userEntity = userRepository.findByLoginName(loginName);
        if (userEntity == null) {
            return null;
        }
        return convertToModel(userEntity);
    }

    // BCrypt-aware password verification for plain service usage.
    // Not used during Spring Security authentication flow (that is handled by the
    // auth provider).
    public boolean verifyPassword(UserModel user) {
        UserEntity userEntity = userRepository.findByLoginName(user.getUserName());
        if (userEntity == null) {
            return false;
        }
        return passwordEncoder.matches(user.getPassword(), userEntity.getPassword());
    }

    // Find a user by id (String -> Long) and map to model.
    public UserModel findById(String id) {
        UserEntity userEntity = userRepository.findById(Long.parseLong(id));
        return convertToModel(userEntity);
    }

    // Delete a user by id (String -> Long).
    public void delete(String id) {
        userRepository.deleteById(Long.parseLong(id));
    }

    // Retrieve all users and map entities -> models.
    public List<UserModel> findAll() {
        List<UserEntity> userEntities = userRepository.findAll();
        return convertToModels(userEntities);
    }

    // Helper: entities -> models.
    private List<UserModel> convertToModels(List<UserEntity> userEntities) {
        List<UserModel> userModels = new ArrayList<>();
        for (UserEntity userEntity : userEntities) {
            userModels.add(convertToModel(userEntity));
        }
        return userModels;
    }

    // Helper: entity -> model.
    // Note: password is copied through; callers that render data should avoid
    // exposing hashes.
    private UserModel convertToModel(UserEntity userEntity) {
        UserModel userModel = new UserModel();
        userModel.setId(userEntity.getId() == null ? null : userEntity.getId().toString());
        userModel.setUserName(userEntity.getUserName());
        userModel.setPassword(userEntity.getPassword());
        userModel.setEnabled(userEntity.isEnabled());
        userModel.setAccountNonExpired(userEntity.isAccountNonExpired());
        userModel.setCredentialsNonExpired(userEntity.isCredentialsNonExpired());
        userModel.setAccountNonLocked(userEntity.isAccountNonLocked());
        userModel.setRoles(userEntity.getRoles());
        return userModel;
    }

    // Helper: model -> entity.
    // Notes:
    // - Id parsing supports update vs create flows.
    // - Roles are expected as Set<String> (e.g., ["ROLE_USER", "ROLE_ADMIN"]).
    private UserEntity convertToEntity(UserModel userModel) {
        UserEntity userEntity = new UserEntity();
        if (userModel.getId() != null) {
            userEntity.setId(Long.parseLong(userModel.getId()));
        }
        userEntity.setUserName(userModel.getUserName());
        userEntity.setPassword(userModel.getPassword());
        userEntity.setEnabled(userModel.isEnabled());
        userEntity.setAccountNonExpired(userModel.isAccountNonExpired());
        userEntity.setCredentialsNonExpired(userModel.isCredentialsNonExpired());
        userEntity.setAccountNonLocked(userModel.isAccountNonLocked());
        userEntity.setRoles(userModel.getRoles());
        return userEntity;
    }

    // Minimal check for BCrypt hash (prefix $2*, covers $2a/$2b/$2y).
    // This is a heuristic; a full BCrypt check requires attempting verification.
    private static boolean isBcrypt(String s) {
        return s != null && s.startsWith("$2");
    }
}
