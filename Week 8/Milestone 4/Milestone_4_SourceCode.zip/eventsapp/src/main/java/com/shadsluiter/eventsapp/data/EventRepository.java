package com.shadsluiter.eventsapp.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.shadsluiter.eventsapp.models.EventEntity;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * EventRepository
 *
 * Repository layer for the Events feature using JdbcTemplate.
 *
 * Purpose in the milestone:
 * - Provides database access methods for CRUD operations.
 * - Uses a custom RowMapper to convert SQL ResultSet rows into EventEntity
 * objects.
 * - Implements the EventRepositoryInterface.
 */
@Repository
public class EventRepository implements EventRepositoryInterface {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public EventRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Find all events created by a specific organizer.
     *
     * @param organizerid the organizer's id
     * @return list of events for that organizer
     */
    @Override
    public List<EventEntity> findByOrganizerid(Long organizerid) {
        String sql = "SELECT * FROM events WHERE organizerid = " + organizerid;
        return jdbcTemplate.query(sql, new EventModelRowMapper());
    }

    /**
     * Find all events in the database.
     */
    @Override
    public List<EventEntity> findAll() {
        String sql = "SELECT * FROM events";
        return jdbcTemplate.query(sql, new EventModelRowMapper());
    }

    /**
     * Delete an event by its id.
     */
    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM events WHERE id = " + id;
        jdbcTemplate.update(sql);
    }

    /**
     * Save a new event or update an existing one.
     * - If id is null → INSERT.
     * - If id is not null → UPDATE.
     *
     * After insert, the new id is fetched using LAST_INSERT_ID().
     */
    @Override
    public EventEntity save(EventEntity event) {
        if (event.getId() == null) {
            String sql = "INSERT INTO events (name, date, location, organizerid, description) " +
                    "VALUES ('" + event.getName() + "', '" + event.getDate() + "', '" + event.getLocation() + "', '"
                    + event.getOrganizerid() + "', '" + event.getDescription() + "')";
            jdbcTemplate.update(sql);
            Long id = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
            event.setId(id);
        } else {
            String sql = "UPDATE events SET name = '" + event.getName() + "', date = '" + event.getDate()
                    + "', location = '" + event.getLocation() + "', organizerid = '" + event.getOrganizerid()
                    + "', description = '" + event.getDescription() +
                    "' WHERE id = " + event.getId();
            jdbcTemplate.update(sql);
        }
        return event;
    }

    /**
     * Find a single event by its id.
     */
    @Override
    public EventEntity findById(Long id) {
        String sql = "SELECT * FROM events WHERE id = " + id;
        return jdbcTemplate.queryForObject(sql, new EventModelRowMapper());
    }

    /**
     * Check if an event exists by id.
     */
    @Override
    public boolean existsById(Long id) {
        String sql = "SELECT COUNT(*) FROM events WHERE id = " + id;
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null && count > 0;
    }

    /**
     * RowMapper that converts a row from the events table into an EventEntity
     * object.
     */
    private static class EventModelRowMapper implements RowMapper<EventEntity> {
        @Override
        public EventEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
            EventEntity event = new EventEntity();
            event.setId(rs.getLong("id"));
            event.setName(rs.getString("name"));
            event.setDate(rs.getDate("date"));
            event.setLocation(rs.getString("location"));
            event.setOrganizerid(rs.getString("organizerid"));
            event.setDescription(rs.getString("description"));
            return event;
        }
    }

    /**
     * Find events that contain a keyword in their description.
     *
     * @param description keyword to search for
     * @return list of matching events
     */
    @Override
    public List<EventEntity> findByDescription(String description) {
        // Treat null safely for LIKE pattern building
        String term = (description == null) ? "" : description.trim();
        String pattern = "%" + term + "%";

        // Parameterized query prevents SQL injection
        String sql = "SELECT * FROM events WHERE description LIKE ?";

        // Pass the pattern as a bind parameter (no string concatenation in SQL)
        return jdbcTemplate.query(sql, new EventModelRowMapper(), pattern);
    }
}
