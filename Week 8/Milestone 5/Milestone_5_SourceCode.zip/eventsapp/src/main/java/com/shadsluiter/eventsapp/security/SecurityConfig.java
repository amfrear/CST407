package com.shadsluiter.eventsapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

/**
 * SecurityConfig
 *
 * Big picture:
 * - TWO chains:
 *   1) API chain (JWT, stateless, CORS, CSRF disabled) for /api/**
 *   2) MVC chain (form login, session, CSRF ON) for pages
 * Additions for Milestone 5:
 * - Force HTTPS on both chains via requiresChannel().anyRequest().requiresSecure()
 * - Emit HSTS header so browsers prefer HTTPS
 */
@Configuration
public class SecurityConfig {

  private final JwtAuthFilter jwtAuthFilter;

  public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
    this.jwtAuthFilter = jwtAuthFilter;
  }

  // =========================
  // 1) API CHAIN: /api/**
  // =========================
  @Bean
  @Order(1)
  public SecurityFilterChain apiChain(HttpSecurity http) throws Exception {
    http
      .securityMatcher("/api/**")
      .csrf(AbstractHttpConfigurer::disable)
      .cors(c -> c.configurationSource(req -> {
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.setAllowedOrigins(List.of("http://localhost:5500", "http://127.0.0.1:5500"));
        cfg.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
        cfg.setAllowedHeaders(List.of("Authorization","Content-Type"));
        cfg.setAllowCredentials(false);
        return cfg;
      }))
      .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(auth -> auth
        .requestMatchers(HttpMethod.POST, "/api/users/register", "/api/users/login").permitAll()
        .requestMatchers(HttpMethod.GET, "/api/events/**").permitAll()
        .anyRequest().authenticated()
      )
      // --- Milestone 5 additions ---
      .requiresChannel(ch -> ch.anyRequest().requiresSecure())
      .headers(h -> h.httpStrictTransportSecurity(hsts -> hsts
        .includeSubDomains(true)
        .maxAgeInSeconds(31536000) // 1 year
      ))
      // -----------------------------
      .addFilterBefore(
        jwtAuthFilter,
        org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class
      );

    return http.build();
  }

  // =========================
  // 2) MVC CHAIN: /** (everything else)
  // =========================
  @Bean
  @Order(2)
  public SecurityFilterChain mvcChain(HttpSecurity http) throws Exception {
    http
      .securityMatcher("/**")
      .csrf(Customizer.withDefaults())
      .authorizeHttpRequests(auth -> auth
        .requestMatchers("/", "/users/loginForm", "/users/register", "/css/**").permitAll()
        .anyRequest().authenticated()
      )
      .formLogin(fl -> fl
        .loginPage("/users/loginForm")
        .loginProcessingUrl("/login")
        .defaultSuccessUrl("/events", true)
        .failureUrl("/users/loginForm?error")
        .permitAll()
      )
      .logout(l -> l
        .logoutUrl("/logout")
        .logoutSuccessUrl("/users/loginForm?logout")
      )
      .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
      // --- Milestone 5 additions ---
      .requiresChannel(ch -> ch.anyRequest().requiresSecure())
      .headers(h -> h.httpStrictTransportSecurity(hsts -> hsts
        .includeSubDomains(true)
        .maxAgeInSeconds(31536000) // 1 year
      ));
      // -----------------------------

    return http.build();
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Bean
  public AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
    return cfg.getAuthenticationManager();
  }
}
