package com.shadsluiter.ordersapp.data;

import com.shadsluiter.ordersapp.models.OrderEntity;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class OrdersDAO {

    private final String url = "jdbc:mysql://localhost:8889/orders-app?allowMultiQueries=true";
    private final String username = "root";
    private final String password = "root";

    public List<OrderEntity> findAll() {
        List<OrderEntity> orders = new ArrayList<>();
        String sql = "SELECT id, date, customerid, notes FROM orders";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                OrderEntity order = new OrderEntity();
                order.setId(rs.getLong("id"));
                order.setDate(rs.getTimestamp("date"));
                order.setCustomerid(rs.getLong("customerid"));
                order.setNotes(rs.getString("notes"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    public OrderEntity findById(Long id) {
        OrderEntity order = null;
        String sql = "SELECT id, date, customerid, notes FROM orders WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    order = new OrderEntity();
                    order.setId(rs.getLong("id"));
                    order.setDate(rs.getTimestamp("date"));
                    order.setCustomerid(rs.getLong("customerid"));
                    order.setNotes(rs.getString("notes"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return order;
    }

    public OrderEntity save(OrderEntity order) {
        String sql = "INSERT INTO orders (date, customerid, notes) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setTimestamp(1, new Timestamp(order.getDate().getTime()));
            ps.setLong(2, order.getCustomerid());
            ps.setString(3, order.getNotes());

            int result = ps.executeUpdate();
            if (result == 1) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        order.setId(rs.getLong(1));
                    }
                }
                return order;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void update(OrderEntity order) {
        String sql = "UPDATE orders SET date = ?, customerid = ?, notes = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, new Timestamp(order.getDate().getTime()));
            ps.setLong(2, order.getCustomerid());
            ps.setString(3, order.getNotes());
            ps.setLong(4, order.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Long id) {
        String sql = "DELETE FROM orders WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<OrderEntity> findByCustomerId(Long id) {
        ArrayList<OrderEntity> orders = new ArrayList<>();
        String sql = "SELECT id, date, customerid, notes FROM orders WHERE customerid = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderEntity order = new OrderEntity();
                    order.setId(rs.getLong("id"));
                    order.setDate(rs.getTimestamp("date"));
                    order.setCustomerid(rs.getLong("customerid"));
                    order.setNotes(rs.getString("notes"));
                    orders.add(order);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    public ArrayList<OrderEntity> findBySearch(String search) {
        ArrayList<OrderEntity> orders = new ArrayList<>();
        String sql = "SELECT id, date, customerid, notes FROM orders WHERE notes LIKE ?";

        System.out.println("[SAFE SQL] " + sql + " [param=%" + search + "%]");

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + search + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderEntity order = new OrderEntity();
                    order.setId(rs.getLong("id"));
                    order.setDate(rs.getTimestamp("date"));
                    order.setCustomerid(rs.getLong("customerid"));
                    order.setNotes(rs.getString("notes"));
                    orders.add(order);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}
